// GPU (OpenGL 3.3) renderer for the GX pipeline. The game's command stream is recorded on the guest thread and
// executed on the thread that owns the GL context.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace ssne {

void gx_use_gpu(bool on);    // choose the renderer before boot (default: software)
bool gx_gpu_active();

// Render thread (GL context current):
bool gpu_renderer_init(void* (*getproc)(const char*), int scale, std::string& err);
bool gpu_renderer_run(int max_frames = 2);   // executes recorded frames; true if a new display frame is ready
void gpu_renderer_set_scale(int scale);      // internal resolution: 1 = 640x528 ... 8
int gpu_renderer_scale();
void gpu_renderer_set_widescreen(float factor);  // EFB rendered this much wider (matches set_widescreen)
struct GpuOutput { uint32_t texture; int w, h; uint64_t seq; float wide; };  // wide: display at 4:3 * wide  // GL texture; row 0 = top of the image
GpuOutput gpu_renderer_output();
bool gpu_renderer_read_output(std::vector<uint32_t>& rgba, int& w, int& h);  // RGBA8, row 0 = top
std::string gpu_renderer_info();
std::string gpu_renderer_phase();
void gpu_renderer_request_dump(const std::string& dir);  // capture the next frame with an EFB copy (step by step)            // what the render thread is doing (for hang reports)
double gpu_renderer_take_max_frame_ms();     // slowest frame since the last call
uint64_t gpu_dropped_frames();               // frames the game dropped because the renderer fell behind
struct GpuStats {
    uint64_t frames, draws, triangles, tex_copies, uploads, reinterpretations, programs, render_targets;
    double shader_ms, frame_ms;
};
GpuStats gpu_renderer_stats();

} // namespace ssne
