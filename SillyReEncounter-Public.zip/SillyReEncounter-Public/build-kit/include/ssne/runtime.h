#pragma once
#include <cstdint>
#include <string>

#include "ssne/ppc_context.h"

namespace ssne {

using FatalHandler = void (*)(const char* message);
void set_fatal_handler(FatalHandler h);
[[noreturn]] void fatal(const char* message);

void reset_cpu(PPCContext& ctx);
void boot_globals(uint32_t mem_size = 0x01800000);

// Load <data_dir>/sys/main.dol into guest RAM and set up what the IPL/apploader would leave behind
// (disc ID, boot info, FST, BI2). Also mounts the disc for the DI emulation. Returns entry point or 0.
uint32_t load_game(const std::string& data_dir, std::string& error);

// Registers native replacements for Dolphin SDK functions found by name in the function table.
void install_sdk_hooks();

// Everything a runner needs: load, scheduler, all native replacements. Returns entry or 0.
uint32_t boot(PPCContext& ctx, const std::string& data_dir, std::string& error);

// Log sink for guest OSReport output (the port shows it in its window).
using LogSink = void (*)(const char* line);
void set_log_sink(LogSink sink);
void log_message(const std::string& line);
// Widescreen: horizontal field-of-view factor applied to the game's perspective projections
// (1 = 4:3, 4/3 = 16:9, 7/4 = 21:9). Takes effect on the next projection the game computes.
// Frame rate limit: 60 = the game's own VI-synced pacing (default), N > 60 = host-paced cap, 0 = unlimited.
void set_frame_limit(int fps);
int frame_limit();
void frame_limiter_wait();  // called by GX at each display copy
// Mouse aim: rotation (radians; +yaw = turn right, +pitch = look up) applied directly to the player's view on
// the next gameplay frame. active() is true while the game is running its first-person look update.
void mouse_aim_add(double yaw, double pitch);
bool mouse_aim_available();
bool mouse_aim_active();
// Pause: the game thread stops at its next display copy until unpaused (port settings menu).
void set_paused(bool paused);
bool paused();
// Gameplay vertical field of view in degrees (the game uses 63); 0 = original.
void set_fov(float degrees);
float fov();
void set_widescreen(float factor);
float widescreen();
float widescreen_frame_factor();  // factor the game's current frame was rendered with (1 outside gameplay)  // runtime diagnostics: stdout + the log sink (ssne.log in the port)

} // namespace ssne
