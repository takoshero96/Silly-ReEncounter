// GPU renderer, render-thread side: executes recorded GX frames with OpenGL 3.3 core.
//
// The EFB is a framebuffer at N x 640x528 (internal resolution scale N). Each draw batch uses a GLSL program
// generated from its TEV configuration; the TEV math is done in integers exactly like the software renderer
// (gx_raster.cpp), which remains the reference. EFB->texture copies are rendered into textures at the internal
// resolution and later sampled directly (optionally reinterpreted into the texture format the game reads them
// as). Display (XFB) copies produce the output texture the port presents.
//
// Row convention: GL framebuffer/texture row y == EFB row y (top at row 0), so presenting flips vertically.
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

#include "gx_gl.h"
#include "gx_gpu_frame.h"
#include "ssne/gx_gpu.h"
#include "ssne/runtime.h"

namespace ssne::gl {
#define SSNE_GL_DEFINE(ret, name, args) PFN_##name name = nullptr;
SSNE_GL_FUNCS(SSNE_GL_DEFINE)
#undef SSNE_GL_DEFINE

bool load(void* (*getproc)(const char*), const char** missing) {
#define SSNE_GL_LOAD(ret, name, args)                                         \
    name = reinterpret_cast<PFN_##name>(getproc("gl" #name));                  \
    if (!name) { if (missing) *missing = "gl" #name; return false; }
    SSNE_GL_FUNCS(SSNE_GL_LOAD)
#undef SSNE_GL_LOAD
    return true;
}
} // namespace ssne::gl

namespace ssne {

using namespace gl;
using gx::DrawCfg;
using gx::GpuCmd;
using gx::GpuFrame;
using gx::GpuState;
using gx::StageCfg;
using gx::Texture;

namespace {

constexpr int EFB_W = gx::EFB_W, EFB_H = gx::EFB_H;

bool g_ready = false;
bool g_gpu_mode = false;
int g_scale = 2;
float g_wide = 1.0f;  // widescreen: the EFB is rendered this much wider (anamorphic), the display stretches it back
// EFB pixel coordinate -> internal framebuffer coordinate
inline int SX(int x) { return int(std::lround(double(x) * g_scale * g_wide)); }
inline int SY(int y) { return y * g_scale; }
std::string g_info;
bool g_trace = getenv("SSNE_GPU_TRACE") != nullptr;

GLuint g_efb_fbo = 0, g_efb_color = 0, g_efb_depth = 0;
GLuint g_out_fbo = 0, g_out_tex = 0;
int g_out_w = 0, g_out_h = 0;
uint64_t g_out_seq = 0;
float g_out_wide = 1.0f;
GLuint g_vao = 0, g_vbo = 0, g_ibo = 0;
GLuint g_white = 0;
std::unordered_map<uint32_t, GLuint> g_samplers;  // by (min filter, mag filter, wrap s, wrap t)
GLuint g_tmp_fbo = 0;

// What the render thread is doing (read by the port's watchdog to report hangs).
std::atomic<const char*> g_phase{"idle"};
std::atomic<uint64_t> g_phase_frame{0};
std::atomic<uint32_t> g_phase_cmd{0}, g_phase_ncmds{0};
double g_max_frame_ms = 0;
uint64_t g_frame_no = 0;
GpuStats g_stats{};

// ------------------------------------------------------------------ helpers
GLuint compile(GLenum type, const std::string& src, std::string& log) {
    GLuint s = CreateShader(type);
    const char* p = src.c_str();
    ShaderSource(s, 1, &p, nullptr);
    CompileShader(s);
    GLint ok = 0;
    GetShaderiv(s, COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[4096];
        GLsizei n = 0;
        GetShaderInfoLog(s, sizeof(buf), &n, buf);
        log.assign(buf, size_t(n));
        DeleteShader(s);
        return 0;
    }
    return s;
}

GLuint link(const std::string& vs, const std::string& fs) {
    std::string log;
    GLuint v = compile(VERTEX_SHADER, vs, log);
    if (!v) { log_message("[gpu] vertex shader error:\n" + log + "\n" + vs); return 0; }
    GLuint f = compile(FRAGMENT_SHADER, fs, log);
    if (!f) { log_message("[gpu] fragment shader error:\n" + log + "\n" + fs); DeleteShader(v); return 0; }
    GLuint p = CreateProgram();
    AttachShader(p, v);
    AttachShader(p, f);
    LinkProgram(p);
    DeleteShader(v);
    DeleteShader(f);
    GLint ok = 0;
    GetProgramiv(p, LINK_STATUS, &ok);
    if (!ok) {
        char buf[4096];
        GLsizei n = 0;
        GetProgramInfoLog(p, sizeof(buf), &n, buf);
        log_message("[gpu] shader link error: " + std::string(buf, size_t(n)));
        DeleteProgram(p);
        return 0;
    }
    return p;
}

GLuint make_tex(int w, int h, GLenum ifmt, GLenum fmt, GLenum type, const void* data, bool linear = false) {
    GLuint t = 0;
    GenTextures(1, &t);
    BindTexture(TEXTURE_2D, t);
    TexParameteri(TEXTURE_2D, TEXTURE_MIN_FILTER, linear ? LINEAR : NEAREST);
    TexParameteri(TEXTURE_2D, TEXTURE_MAG_FILTER, linear ? LINEAR : NEAREST);
    TexParameteri(TEXTURE_2D, TEXTURE_WRAP_S, CLAMP_TO_EDGE);
    TexParameteri(TEXTURE_2D, TEXTURE_WRAP_T, CLAMP_TO_EDGE);
    TexParameteri(TEXTURE_2D, TEXTURE_MAX_LEVEL, 0);
    PixelStorei(UNPACK_ALIGNMENT, 4);
    TexImage2D(TEXTURE_2D, 0, GLint(ifmt), w, h, 0, fmt, type, data);
    return t;
}

GLuint fbo_for(GLuint color, GLuint depth = 0) {
    GLuint f = 0;
    GenFramebuffers(1, &f);
    BindFramebuffer(FRAMEBUFFER, f);
    FramebufferTexture2D(FRAMEBUFFER, COLOR_ATTACHMENT0, TEXTURE_2D, color, 0);
    if (depth) FramebufferTexture2D(FRAMEBUFFER, DEPTH_STENCIL_ATTACHMENT, TEXTURE_2D, depth, 0);
    if (CheckFramebufferStatus(FRAMEBUFFER) != FRAMEBUFFER_COMPLETE) log_message("[gpu] framebuffer incomplete");
    return f;
}

// Fixed-function state for internal full-screen passes (copies, reinterpretation). Clip distances must be off:
// these shaders don't write gl_ClipDistance, and enabled-but-unwritten clip distances are undefined (NVIDIA
// clips everything, Mesa doesn't).
void pass_state() {
    Disable(SCISSOR_TEST); Disable(BLEND); Disable(COLOR_LOGIC_OP); Disable(DEPTH_TEST); Disable(CULL_FACE);
    Disable(CLIP_DISTANCE0); Disable(CLIP_DISTANCE1); Disable(GLenum(CLIP_DISTANCE0 + 2));
    ColorMask(1, 1, 1, 1);
    DepthMask(0);
}

// ------------------------------------------------------------------ frame capture (debugging)
std::string g_dump_dir;
std::atomic<bool> g_dump_req{false};
bool g_dumping = false;
int g_dump_n = 0;
FILE* g_dump_log = nullptr;

void write_bmp(const std::string& path, int w, int h, const std::vector<uint32_t>& px) {  // px row 0 = top
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return;
    int row = (w * 3 + 3) & ~3;
    uint32_t size = 54 + uint32_t(row) * uint32_t(h);
    uint8_t hdr[54] = {'B', 'M'};
    auto put32 = [&](int o, uint32_t v) { for (int i = 0; i < 4; i++) hdr[o + i] = uint8_t(v >> (8 * i)); };
    put32(2, size); put32(10, 54); put32(14, 40); put32(18, uint32_t(w)); put32(22, uint32_t(h));
    hdr[26] = 1; hdr[28] = 24;
    fwrite(hdr, 1, 54, f);
    std::vector<uint8_t> line(size_t(row), 0);
    for (int y = h - 1; y >= 0; y--) {
        for (int x = 0; x < w; x++) {
            uint32_t c = px[size_t(y) * w + x];
            line[size_t(x) * 3] = uint8_t(c >> 16); line[size_t(x) * 3 + 1] = uint8_t(c >> 8); line[size_t(x) * 3 + 2] = uint8_t(c);
        }
        fwrite(line.data(), 1, line.size(), f);
    }
    fclose(f);
}

void dump_fbo(GLuint fbo, int w, int h, const std::string& tag) {
    if (!g_dumping) return;
    std::vector<uint32_t> px(size_t(w) * h);
    BindFramebuffer(FRAMEBUFFER, fbo);
    PixelStorei(PACK_ALIGNMENT, 4);
    ReadPixels(0, 0, w, h, RGBA, UNSIGNED_BYTE, px.data());
    char name[64];
    snprintf(name, sizeof(name), "%03d_", g_dump_n++);
    write_bmp(g_dump_dir + "/" + name + tag + ".bmp", w, h, px);
    if (g_dump_log) {
        uint64_t sum = 0; uint32_t nonblack = 0;
        for (uint32_t c : px) { sum += (c & 255) + ((c >> 8) & 255) + ((c >> 16) & 255); nonblack += (c & 0xFFFFFF) != 0; }
        fprintf(g_dump_log, "  -> %s%s.bmp %dx%d avg %.1f nonblack %.1f%%\n", name, tag.c_str(), w, h,
                double(sum) / (3.0 * double(px.size())), 100.0 * nonblack / double(px.size()));
    }
}

void dump_depth(const std::string& tag) {
    if (!g_dumping) return;
    int w = SX(EFB_W), h = SY(EFB_H);
    std::vector<float> d(size_t(w) * h);
    BindFramebuffer(FRAMEBUFFER, g_efb_fbo);
    ReadPixels(0, 0, w, h, DEPTH_COMPONENT, FLOAT, d.data());
    std::vector<uint32_t> px(d.size());
    float mn = 1, mx = 0;
    for (size_t i = 0; i < d.size(); i++) {
        uint32_t v = uint32_t(std::clamp(d[i], 0.f, 1.f) * 255.f);
        px[i] = v | v << 8 | v << 16;
        mn = std::min(mn, d[i]); mx = std::max(mx, d[i]);
    }
    char name[64];
    snprintf(name, sizeof(name), "%03d_", g_dump_n++);
    write_bmp(g_dump_dir + "/" + name + tag + ".bmp", w, h, px);
    if (g_dump_log) fprintf(g_dump_log, "  -> %s%s.bmp depth min %.6f max %.6f\n", name, tag.c_str(), mn, mx);
}

// ------------------------------------------------------------------ samplers
GLuint sampler_for(uint32_t minf, bool mag_linear, uint32_t ws, uint32_t wt) {
    uint32_t key = minf | uint32_t(mag_linear) << 3 | ws << 4 | wt << 6;
    auto it = g_samplers.find(key);
    if (it != g_samplers.end()) return it->second;
    static const GLenum wraps[3] = {CLAMP_TO_EDGE, REPEAT, MIRRORED_REPEAT};
    GLenum min;
    switch (minf) {
    case 0: min = NEAREST; break;
    case 1: min = NEAREST_MIPMAP_NEAREST; break;
    case 2: min = NEAREST_MIPMAP_LINEAR; break;
    case 5: min = LINEAR_MIPMAP_NEAREST; break;
    case 6: min = LINEAR_MIPMAP_LINEAR; break;
    default: min = LINEAR; break;
    }
    GLuint smp = 0;
    GenSamplers(1, &smp);
    SamplerParameteri(smp, TEXTURE_MIN_FILTER, GLint(min));
    SamplerParameteri(smp, TEXTURE_MAG_FILTER, mag_linear ? LINEAR : NEAREST);
    SamplerParameteri(smp, TEXTURE_WRAP_S, GLint(wraps[ws]));
    SamplerParameteri(smp, TEXTURE_WRAP_T, GLint(wraps[wt]));
    g_samplers[key] = smp;
    return smp;
}

// ------------------------------------------------------------------ render-target pool
// EFB copies and reinterpreted views are full-size render targets created every frame by the game's effects.
// They are recycled (same size -> same texture + framebuffer) instead of being allocated and deleted each frame,
// which makes some drivers (NVIDIA) synchronize.
struct RT { GLuint tex = 0, fbo = 0; int w = 0, h = 0; };
std::vector<RT> g_rt_free;

RT rt_acquire(int w, int h) {
    for (size_t i = 0; i < g_rt_free.size(); i++)
        if (g_rt_free[i].w == w && g_rt_free[i].h == h) {
            RT r = g_rt_free[i];
            g_rt_free.erase(g_rt_free.begin() + long(i));
            return r;
        }
    RT r;
    r.w = w; r.h = h;
    r.tex = make_tex(w, h, RGBA8, RGBA, UNSIGNED_BYTE, nullptr);
    r.fbo = fbo_for(r.tex);
    g_stats.render_targets++;
    return r;
}
void rt_release(const RT& r) {
    g_rt_free.push_back(r);
    if (g_rt_free.size() > 24) {  // cap the pool
        RT old = g_rt_free.front();
        g_rt_free.erase(g_rt_free.begin());
        DeleteFramebuffers(1, &old.fbo);
        DeleteTextures(1, &old.tex);
    }
}

// ------------------------------------------------------------------ textures
struct GlTex { GLuint tex; int w, h; uint64_t last_used; };
std::unordered_map<uint64_t, GlTex> g_textures;     // decoded RAM textures by Texture::id
struct PooledTex { RT rt; uint64_t last_used; };
std::unordered_map<uint64_t, PooledTex> g_copies;   // EFB copies by copy id (raw RGBA8 at internal res)
std::unordered_map<uint64_t, PooledTex> g_views;    // reinterpreted copies: key = copy id * 16 + tex format

GLuint g_copy_prog = 0, g_reint_prog = 0;
GLint g_copy_u_rect = -1, g_copy_u_half = -1;
GLint g_reint_u_mode = -1;

void create_efb() {
    int w = SX(EFB_W), h = SY(EFB_H);
    if (g_efb_fbo) { DeleteFramebuffers(1, &g_efb_fbo); DeleteTextures(1, &g_efb_color); DeleteTextures(1, &g_efb_depth); }
    g_efb_color = make_tex(w, h, RGBA8, RGBA, UNSIGNED_BYTE, nullptr, true);
    g_efb_depth = make_tex(w, h, DEPTH24_STENCIL8, DEPTH_STENCIL, UNSIGNED_INT_24_8, nullptr);
    g_efb_fbo = fbo_for(g_efb_color, g_efb_depth);
    ClearColor(0, 0, 0, 0);
    ClearDepth(1.0);
    Disable(SCISSOR_TEST);
    ColorMask(1, 1, 1, 1);
    DepthMask(1);
    Clear(COLOR_BUFFER_BIT | DEPTH_BUFFER_BIT);
}

GLuint texture_for(const Texture* t) {
    if (!t || t->w == 0) return g_white;
    if (t->efb_copy >= 0) {
        uint64_t key = uint64_t(t->efb_copy) * 16 + t->tex_fmt;
        auto it = g_views.find(key);
        if (it != g_views.end()) { it->second.last_used = g_frame_no; return it->second.rt.tex; }
        auto ct = g_copies.find(uint64_t(t->efb_copy));
        if (ct == g_copies.end()) return g_white;
        // Reinterpret: encode each texel as the copy format, decode it as the texture format.
        g_phase = "reinterpret";
        RT out = rt_acquire(ct->second.rt.w, ct->second.rt.h);
        BindFramebuffer(FRAMEBUFFER, out.fbo);
        Viewport(0, 0, out.w, out.h);
        pass_state();
        UseProgram(g_reint_prog);
        GLint mode[4] = {t->copy_fmt, t->tex_fmt, t->intensity ? 1 : 0, 0};
        Uniform4iv(g_reint_u_mode, 1, mode);
        ActiveTexture(TEXTURE0);
        BindTexture(TEXTURE_2D, ct->second.rt.tex);
        BindSampler(0, 0);
        DrawArrays(TRIANGLES, 0, 3);
        BindFramebuffer(FRAMEBUFFER, g_efb_fbo);
        Viewport(0, 0, SX(EFB_W), SY(EFB_H));
        g_views[key] = {out, g_frame_no};
        if (g_dumping) {
            if (g_dump_log) fprintf(g_dump_log, "  reinterpret copy %lld fmt %u -> tex fmt %u (intensity %d)\n", (long long)t->efb_copy,
                                    t->copy_fmt, t->tex_fmt, t->intensity);
            dump_fbo(out.fbo, out.w, out.h, "reinterpreted");
            BindFramebuffer(FRAMEBUFFER, g_efb_fbo);
        }
        g_stats.reinterpretations++;
        g_phase = "draw";
        return out.tex;
    }
    auto it = g_textures.find(t->id);
    if (it != g_textures.end()) { it->second.last_used = g_frame_no; return it->second.tex; }
    const char* prev_phase = g_phase;
    g_phase = "texture upload";
    GLuint tex = make_tex(t->w, t->h, RGBA8, RGBA, UNSIGNED_BYTE, t->rgba.data());
    g_phase = prev_phase;
    if (!t->mips.empty()) {
        for (size_t k = 0; k < t->mips.size(); k++)
            TexImage2D(TEXTURE_2D, GLint(k + 1), GLint(RGBA8), std::max(1, t->w >> (k + 1)), std::max(1, t->h >> (k + 1)), 0,
                       RGBA, UNSIGNED_BYTE, t->mips[k].data());
        TexParameteri(TEXTURE_2D, TEXTURE_MAX_LEVEL, GLint(t->mips.size()));
    }
    g_textures[t->id] = {tex, t->w, t->h, g_frame_no};
    g_stats.uploads++;
    return tex;
}

void evict() {
    auto sweep = [](auto& m, uint64_t age) {
        for (auto it = m.begin(); it != m.end();) {
            if (g_frame_no - it->second.last_used > age) { DeleteTextures(1, &it->second.tex); it = m.erase(it); }
            else ++it;
        }
    };
    sweep(g_textures, 600);
    auto sweep_rt = [](auto& m, uint64_t age) {
        for (auto it = m.begin(); it != m.end();) {
            if (g_frame_no - it->second.last_used > age) { rt_release(it->second.rt); it = m.erase(it); }
            else ++it;
        }
    };
    sweep_rt(g_views, 3);
    sweep_rt(g_copies, 6);
}

// ------------------------------------------------------------------ TEV program generation
struct Program {
    GLuint prog = 0;
    GLint u_vp0, u_vp1, u_efb, u_reg, u_konst, u_aref, u_stscale, u_calpha, u_zrange, u_fog, u_fogcolor;
    GLint u_indmtx, u_texsz, u_su;
};
std::unordered_map<std::string, Program> g_programs;

const char* kFixedK[8] = {"255", "223", "191", "159", "128", "96", "64", "32"};

std::string konst_color(uint32_t sel) {
    if (sel < 8) return std::string("ivec3(") + kFixedK[sel] + ")";
    if (sel >= 12 && sel <= 15) return "u_konst[" + std::to_string(sel - 12) + "].rgb";
    if (sel >= 16) return "ivec3(u_konst[" + std::to_string((sel - 16) & 3) + "][" + std::to_string((sel - 16) >> 2) + "])";
    return "ivec3(0)";
}
std::string konst_alpha(uint32_t sel) {
    if (sel < 8) return kFixedK[sel];
    if (sel >= 12 && sel <= 15) return "u_konst[" + std::to_string(sel - 12) + "].a";
    if (sel >= 16) return "u_konst[" + std::to_string((sel - 16) & 3) + "][" + std::to_string((sel - 16) >> 2) + "]";
    return "0";
}

std::string color_in(uint32_t sel, const StageCfg& st) {
    switch (sel) {
    case 0: return "R[0].rgb"; case 1: return "R[0].aaa";
    case 2: return "R[1].rgb"; case 3: return "R[1].aaa";
    case 4: return "R[2].rgb"; case 5: return "R[2].aaa";
    case 6: return "R[3].rgb"; case 7: return "R[3].aaa";
    case 8: return "tx.rgb"; case 9: return "tx.aaa";
    case 10: return "rc.rgb"; case 11: return "rc.aaa";
    case 12: return "ivec3(255)"; case 13: return "ivec3(128)";
    case 14: return konst_color(st.kcsel);
    default: return "ivec3(0)";
    }
}
std::string alpha_in(uint32_t sel, const StageCfg& st) {
    switch (sel) {
    case 0: return "R[0].a"; case 1: return "R[1].a"; case 2: return "R[2].a"; case 3: return "R[3].a";
    case 4: return "tx.a"; case 5: return "rc.a"; case 6: return konst_alpha(st.kasel);
    default: return "0";
    }
}

const char* kComp[8] = {"false", "(a < r)", "(a == r)", "(a <= r)", "(a > r)", "(a != r)", "(a >= r)", "true"};

std::string gen_vs(int ntex) {
    std::string s = "#version 330 core\n"
                    "layout(location=0) in vec4 a_pos;\nlayout(location=1) in vec4 a_col0;\nlayout(location=2) in vec4 a_col1;\n";
    for (int i = 0; i < ntex; i++) s += "layout(location=" + std::to_string(3 + i) + ") in vec3 a_tex" + std::to_string(i) + ";\n";
    s += "uniform vec4 u_vp0, u_vp1;\nuniform vec2 u_efb;\nout vec4 v_col0, v_col1;\n";
    for (int i = 0; i < ntex; i++) s += "out vec3 v_tex" + std::to_string(i) + ";\n";
    s += "void main() {\n"
         "  vec4 p = a_pos;\n"
         "  float px = p.x * u_vp0.x + u_vp1.x * p.w;\n"
         "  float py = p.y * u_vp0.y + u_vp1.y * p.w;\n"
         "  float pz = (p.z * u_vp0.z + u_vp1.z * p.w) * (1.0 / 16777216.0);\n"
         "  gl_Position = vec4(px * 2.0 / u_efb.x - p.w, py * 2.0 / u_efb.y - p.w, pz * 2.0 - p.w, p.w);\n"
         "  // GX clips z < -w and z > 0; geometry exactly on a plane (common for full-screen quads) must survive\n"
         "  gl_ClipDistance[0] = p.z + p.w + abs(p.w) * 1e-5;\n  gl_ClipDistance[1] = -p.z + abs(p.w) * 1e-5;\n"
         "  gl_ClipDistance[2] = p.w - 1e-5;\n"
         "  v_col0 = a_col0 * 255.0;\n  v_col1 = a_col1 * 255.0;\n";
    for (int i = 0; i < ntex; i++) s += "  v_tex" + std::to_string(i) + " = a_tex" + std::to_string(i) + ";\n";
    s += "}\n";
    return s;
}

std::string gen_fs(const DrawCfg& c, int ntex) {
    std::string s = "#version 330 core\n";
    s += "in vec4 v_col0, v_col1;\n";
    for (int i = 0; i < ntex; i++) s += "in vec3 v_tex" + std::to_string(i) + ";\n";
    s += "uniform sampler2D u_samp[8];\nuniform ivec4 u_reg[4];\nuniform ivec4 u_konst[4];\nuniform ivec4 u_aref;\n"
         "uniform vec2 u_stscale[16];\nuniform float u_calpha;\nuniform vec2 u_zrange;\n"
         "uniform vec4 u_fog;   // a, c, b magnitude, b shift\nuniform ivec4 u_fogcolor;\n"
         "uniform ivec4 u_indmtx[6];  // per matrix: (ma, mc, me, shift), (mb, md, mf, 0)\n"
         "uniform vec2 u_texsz[8];    // texture size per map (game texels)\nuniform vec2 u_su[8];  // SU scale per texcoord\n"
         "layout(location=0, index=0) out vec4 o_col;\nlayout(location=0, index=1) out vec4 o_src1;\n"
         "void main() {\n"
         "  ivec4 R[4];\n  R[0] = u_reg[0]; R[1] = u_reg[1]; R[2] = u_reg[2]; R[3] = u_reg[3];\n"
         "  ivec4 ras0 = ivec4(floor(v_col0 + 0.5)), ras1 = ivec4(floor(v_col1 + 0.5));\n"
         "  // Depth on the near/far clip planes is snapped exactly to the plane, so geometry lying on a plane (screen\n"
         "  // quads) and geometry clipped by it compare equal, like on the console.\n"
         "  float zsnap = gl_FragCoord.z;\n"
         "  if (abs(zsnap - u_zrange.x) < 4e-6) zsnap = u_zrange.x; else if (abs(zsnap - u_zrange.y) < 4e-6) zsnap = u_zrange.y;\n"
         "  zsnap = clamp(zsnap, 0.0, 1.0);\n"
         "  gl_FragDepth = zsnap;\n"
         "  ivec4 tx, rc;\n";
    const char* ch = "rgba";
    auto fixuv = [&](int coord) {  // fixed-point (1/128 texel) texture coordinate, as the hardware computes it
        if (coord >= ntex) return std::string("ivec2(0)");
        std::string v = "v_tex" + std::to_string(coord), n = std::to_string(coord);
        return "ivec2(" + v + ".xy / (" + v + ".z != 0.0 ? " + v + ".z : 1.0) * u_su[" + n + "] * 128.0)";
    };
    if (c.nind) {
        s += "  ivec3 iind[4]; ivec2 tevc = ivec2(0); int abump = 0;\n";
        for (int i = 0; i < c.nind; i++) {
            std::string m = std::to_string(c.ind_map[i]);
            s += "  { ivec2 u = " + fixuv(c.ind_coord[i]) + "; u = ivec2(u.x >> " + std::to_string(c.ind_ss[i]) + ", u.y >> " +
                 std::to_string(c.ind_ts[i]) + ");\n    ivec4 r = ivec4(floor(texture(u_samp[" + m + "], vec2(u) / 128.0 / u_texsz[" + m +
                 "]) * 255.0 + 0.5));\n    iind[" + std::to_string(i) + "] = ivec3(r.a, r.b, r.g); }\n";
        }
    }
    for (int si = 0; si < c.stages; si++) {
        const StageCfg& st = c.st[si];
        s += "  // stage " + std::to_string(si) + "\n";
        if (st.ind) {
            uint32_t cmd = st.ind;
            uint32_t bt = cmd & 3, fmt = (cmd >> 2) & 3, bias = (cmd >> 4) & 7, bs = (cmd >> 7) & 3, mid = (cmd >> 9) & 15;
            uint32_t sw = (cmd >> 13) & 7, tw = (cmd >> 16) & 7, fb = (cmd >> 20) & 1;
            static const char* bump_mask[4] = {"248", "224", "240", "248"};
            static const char* fmt_mask[4] = {"255", "31", "15", "7"};
            s += "  { ivec3 crd = " + (int(bt) < c.nind ? "iind[" + std::to_string(bt) + "]" : std::string("ivec3(0)")) + ";\n";
            if (bs) s += std::string("    abump = crd.") + "xyz"[bs - 1] + " & " + bump_mask[fmt] + ";\n";
            s += std::string("    crd &= ") + fmt_mask[fmt] + ";\n";
            for (int k = 0; k < 3; k++)
                if (bias & (1u << k)) s += std::string("    crd.") + "xyz"[k] + (fmt == 0 ? " -= 128;\n" : " += 1;\n");
            s += "    ivec2 uv = " + fixuv(st.texcoord) + ";\n    ivec2 tr = ivec2(0);\n";
            int m = -1;
            if (mid >= 1 && mid <= 3) {
                m = int(mid) - 1;
                std::string a = "u_indmtx[" + std::to_string(2 * m) + "]", b = "u_indmtx[" + std::to_string(2 * m + 1) + "]";
                s += "    tr = ivec2(" + a + ".x * crd.x + " + a + ".y * crd.y + " + a + ".z * crd.z, " + b + ".x * crd.x + " + b +
                     ".y * crd.y + " + b + ".z * crd.z) >> 3;\n";
            } else if (mid >= 5 && mid <= 7) {
                m = int(mid) - 5;
                s += "    tr = (uv * crd.x) >> 8;\n";
            } else if (mid >= 9 && mid <= 11) {
                m = int(mid) - 9;
                s += "    tr = (uv * crd.y) >> 8;\n";
            }
            if (m >= 0) {
                std::string sh = "u_indmtx[" + std::to_string(2 * m) + "].w";
                s += "    tr = " + sh + " >= 0 ? (tr >> " + sh + ") : (tr << -" + sh + ");\n";
            }
            auto wrap = [](const std::string& v, uint32_t mode) -> std::string {
                static const char* sz[6] = {"", "32767", "16383", "8191", "4095", "2047"};
                if (mode == 0 || mode == 7) return v;
                if (mode == 6) return "0";
                return "(" + v + " & " + sz[mode] + ")";
            };
            s += "    ivec2 w = ivec2(" + wrap("uv.x", sw) + ", " + wrap("uv.y", tw) + ") + tr;\n";
            s += fb ? "    tevc += w; }\n" : "    tevc = w; }\n";
        } else if (c.nind) {
            s += "  tevc = " + fixuv(st.texcoord) + ";\n";
        }
        if (st.tex_enabled && st.ind) {
            std::string m = std::to_string(st.texmap);
            s += "  { ivec4 raw = ivec4(floor(texture(u_samp[" + m + "], vec2(tevc) / 128.0 / u_texsz[" + m + "]) * 255.0 + 0.5));\n"
                 "    tx = ivec4(raw." + ch[st.swap_tex[0]] + ", raw." + ch[st.swap_tex[1]] + ", raw." + ch[st.swap_tex[2]] +
                 ", raw." + ch[st.swap_tex[3]] + "); }\n";
        } else if (st.tex_enabled) {
            std::string tcv = st.texcoord < ntex ? "v_tex" + std::to_string(st.texcoord) : "vec3(0.0)";
            s += "  { vec3 t = " + tcv + "; float q = t.z != 0.0 ? t.z : 1.0;\n"
                 "    ivec4 raw = ivec4(floor(texture(u_samp[" + std::to_string(st.texmap) + "], t.xy / q * u_stscale[" +
                 std::to_string(si) + "]) * 255.0 + 0.5));\n"
                 "    tx = ivec4(raw." + ch[st.swap_tex[0]] + ", raw." + ch[st.swap_tex[1]] + ", raw." + ch[st.swap_tex[2]] +
                 ", raw." + ch[st.swap_tex[3]] + "); }\n";
        } else {
            s += "  tx = ivec4(255);\n";
        }
        if (st.ras_chan >= 2) {
            s += st.ras_chan == 2 ? "  rc = ivec4(abump);\n" : "  rc = ivec4(abump | (abump >> 5));\n";
        } else if (st.ras_chan >= 0) {
            std::string r = st.ras_chan == 0 ? "ras0" : "ras1";
            s += "  rc = ivec4(" + r + "." + ch[st.swap_ras[0]] + ", " + r + "." + ch[st.swap_ras[1]] + ", " + r + "." +
                 ch[st.swap_ras[2]] + ", " + r + "." + ch[st.swap_ras[3]] + ");\n";
        } else {
            s += "  rc = ivec4(0);\n";
        }
        // color
        uint32_t ce = st.cenv, ae = st.aenv;
        {
            uint32_t sd = ce & 15, sc = (ce >> 4) & 15, sb = (ce >> 8) & 15, sa = (ce >> 12) & 15;
            uint32_t bias = (ce >> 16) & 3, op = (ce >> 18) & 1, clampf = (ce >> 19) & 1, scale = (ce >> 20) & 3;
            uint32_t dest = (ce >> 22) & 3;
            s += "  { ivec3 a = " + color_in(sa, st) + " & 255, b = " + color_in(sb, st) + " & 255, cc = " + color_in(sc, st) +
                 " & 255, d = " + color_in(sd, st) + ";\n    ivec3 v;\n";
            if (bias == 3) {
                uint32_t mode = (scale << 1) | op;
                switch (mode) {
                case 0: s += "    bool cnd = a.r > b.r; v = d + (cnd ? cc : ivec3(0));\n"; break;
                case 1: s += "    bool cnd = a.r == b.r; v = d + (cnd ? cc : ivec3(0));\n"; break;
                case 2: s += "    bool cnd = (a.g * 256 + a.r) > (b.g * 256 + b.r); v = d + (cnd ? cc : ivec3(0));\n"; break;
                case 3: s += "    bool cnd = (a.g * 256 + a.r) == (b.g * 256 + b.r); v = d + (cnd ? cc : ivec3(0));\n"; break;
                case 4: s += "    bool cnd = (a.b * 65536 + a.g * 256 + a.r) > (b.b * 65536 + b.g * 256 + b.r); v = d + (cnd ? cc : ivec3(0));\n"; break;
                case 5: s += "    bool cnd = (a.b * 65536 + a.g * 256 + a.r) == (b.b * 65536 + b.g * 256 + b.r); v = d + (cnd ? cc : ivec3(0));\n"; break;
                case 6: s += "    v = d + ivec3(greaterThan(a, b)) * cc;\n"; break;
                default: s += "    v = d + ivec3(equal(a, b)) * cc;\n"; break;
                }
            } else {
                s += "    ivec3 c2 = cc + (cc >> 7);\n";
                s += std::string("    ivec3 lrp = ((a << 8) + (b - a) * c2 + ") + (op ? "127" : "128") + ") >> 8;\n";
                s += std::string("    v = d ") + (op ? "- lrp" : "+ lrp") + ";\n";
                if (bias == 1) s += "    v += 128;\n"; else if (bias == 2) s += "    v -= 128;\n";
                if (scale == 1) s += "    v *= 2;\n"; else if (scale == 2) s += "    v *= 4;\n"; else if (scale == 3) s += "    v >>= 1;\n";
            }
            s += clampf ? "    v = clamp(v, 0, 255);\n" : "    v = clamp(v, -1024, 1023);\n";
            s += "    ivec3 cres = v;\n";
            // alpha
            uint32_t ad = (ae >> 4) & 7, ac = (ae >> 7) & 7, ab = (ae >> 10) & 7, aa = (ae >> 13) & 7;
            uint32_t abias = (ae >> 16) & 3, aop = (ae >> 18) & 1, aclamp = (ae >> 19) & 1, ascale = (ae >> 20) & 3;
            uint32_t adest = (ae >> 22) & 3;
            s += "    int aa = " + alpha_in(aa, st) + " & 255, ab = " + alpha_in(ab, st) + " & 255, ac = " + alpha_in(ac, st) +
                 " & 255, ad = " + alpha_in(ad, st) + ";\n    int av;\n";
            if (abias == 3) {
                uint32_t mode = (ascale << 1) | aop;
                s += (mode & 1) ? "    av = ad + ((aa == ab) ? ac : 0);\n" : "    av = ad + ((aa > ab) ? ac : 0);\n";
            } else {
                s += "    int ac2 = ac + (ac >> 7);\n";
                s += std::string("    int alrp = ((aa << 8) + (ab - aa) * ac2 + ") + (aop ? "127" : "128") + ") >> 8;\n";
                s += std::string("    av = ad ") + (aop ? "- alrp" : "+ alrp") + ";\n";
                if (abias == 1) s += "    av += 128;\n"; else if (abias == 2) s += "    av -= 128;\n";
                if (ascale == 1) s += "    av *= 2;\n"; else if (ascale == 2) s += "    av *= 4;\n"; else if (ascale == 3) s += "    av >>= 1;\n";
            }
            s += aclamp ? "    av = clamp(av, 0, 255);\n" : "    av = clamp(av, -1024, 1023);\n";
            s += "    R[" + std::to_string(dest) + "].rgb = cres;\n";
            s += "    R[" + std::to_string(adest) + "].a = av; }\n";
        }
    }
    s += "  ivec4 o = clamp(R[0], 0, 255);\n";
    if (!c.atest_always) {
        uint32_t ac = c.alpha_cmp;
        uint32_t f0 = (ac >> 16) & 7, f1 = (ac >> 19) & 7, logic = (ac >> 22) & 3;
        std::string c0 = kComp[f0], c1 = kComp[f1];
        auto sub = [](std::string e, const char* ref) {
            for (size_t p; (p = e.find(" r)")) != std::string::npos;) e.replace(p, 3, std::string(" ") + ref + ")");
            for (size_t p; (p = e.find("(a ")) != std::string::npos;) e.replace(p, 3, "(o.a ");
            return e;
        };
        std::string r0 = sub(c0, "u_aref.x"), r1 = sub(c1, "u_aref.y");
        const char* ops[4] = {"&&", "||", "!=", "=="};
        s += "  if (!((" + r0 + ") " + ops[logic] + " (" + r1 + "))) discard;\n";
    }
    if (c.fog_sel >= 2) {  // GX fog (same math as the software renderer)
        s += "  { int zi = int(zsnap * 16777215.0 + 0.5);\n";
        s += c.fog_proj == 0 ? "    float den = u_fog.z - float(zi >> int(u_fog.w));\n    float ze = den != 0.0 ? (u_fog.x * 16777216.0) / den : 0.0;\n"
                             : "    float ze = u_fog.x * float(zi) / 16777216.0;\n";
        s += "    float f = clamp(ze - u_fog.y, 0.0, 1.0);\n";
        switch (c.fog_sel) {
        case 4: s += "    f = 1.0 - exp2(-8.0 * f);\n"; break;
        case 5: s += "    f = 1.0 - exp2(-8.0 * f * f);\n"; break;
        case 6: s += "    f = exp2(-8.0 * (1.0 - f));\n"; break;
        case 7: s += "    f = exp2(-8.0 * (1.0 - f) * (1.0 - f));\n"; break;
        default: break;
        }
        s += "    int ifog = int(floor(f * 256.0 + 0.5));\n    o.rgb = (o.rgb * (256 - ifog) + u_fogcolor.rgb * ifog) >> 8; }\n";
    }
    s += c.const_alpha_en ? "  o_col = vec4(vec3(o.rgb) / 255.0, u_calpha);\n" : "  o_col = vec4(o) / 255.0;\n";
    s += "  o_src1 = vec4(float(o.a) / 255.0);\n}\n";
    return s;
}

std::string program_key(const DrawCfg& c, int ntex) {
    std::string k;
    auto put = [&](uint32_t v) { k.append(reinterpret_cast<const char*>(&v), 4); };
    put(uint32_t(c.stages)); put(uint32_t(ntex));
    for (int i = 0; i < c.stages; i++) {
        const StageCfg& st = c.st[i];
        put(st.cenv); put(st.aenv);
        put(uint32_t(st.texmap) | uint32_t(st.texcoord) << 4 | uint32_t(st.tex_enabled) << 8 | uint32_t(st.ras_chan + 1) << 9);
        put(st.kcsel | st.kasel << 8);
        uint32_t sw = 0;
        for (int j = 0; j < 4; j++) sw |= uint32_t(st.swap_ras[j]) << (j * 2) | uint32_t(st.swap_tex[j]) << (8 + j * 2);
        put(sw);
        put(st.ind);
    }
    put(uint32_t(c.nind));
    for (int i = 0; i < c.nind; i++)
        put(uint32_t(c.ind_map[i]) | uint32_t(c.ind_coord[i]) << 4 | uint32_t(c.ind_ss[i]) << 8 | uint32_t(c.ind_ts[i]) << 12);
    put(c.atest_always ? 0xFFFFFFFFu : (c.alpha_cmp >> 16));
    put(c.const_alpha_en);
    put(uint32_t(c.fog_sel) | uint32_t(c.fog_proj) << 8);
    return k;
}

Program* program_for(const DrawCfg& c, int ntex) {
    std::string key = program_key(c, ntex);
    auto it = g_programs.find(key);
    if (it != g_programs.end()) return it->second.prog ? &it->second : nullptr;
    Program p;
    const char* prev_phase = g_phase;
    g_phase = "compile shader";
    auto t0 = std::chrono::steady_clock::now();
    p.prog = link(gen_vs(ntex), gen_fs(c, ntex));
    g_stats.shader_ms += std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    g_stats.programs++;
    if (p.prog) {
        UseProgram(p.prog);
        GLint units[8] = {0, 1, 2, 3, 4, 5, 6, 7};
        Uniform1iv(GetUniformLocation(p.prog, "u_samp"), 8, units);
        p.u_vp0 = GetUniformLocation(p.prog, "u_vp0");
        p.u_vp1 = GetUniformLocation(p.prog, "u_vp1");
        p.u_efb = GetUniformLocation(p.prog, "u_efb");
        p.u_reg = GetUniformLocation(p.prog, "u_reg");
        p.u_konst = GetUniformLocation(p.prog, "u_konst");
        p.u_aref = GetUniformLocation(p.prog, "u_aref");
        p.u_stscale = GetUniformLocation(p.prog, "u_stscale");
        p.u_calpha = GetUniformLocation(p.prog, "u_calpha");
        p.u_zrange = GetUniformLocation(p.prog, "u_zrange");
        p.u_fog = GetUniformLocation(p.prog, "u_fog");
        p.u_fogcolor = GetUniformLocation(p.prog, "u_fogcolor");
        p.u_indmtx = GetUniformLocation(p.prog, "u_indmtx");
        p.u_texsz = GetUniformLocation(p.prog, "u_texsz");
        p.u_su = GetUniformLocation(p.prog, "u_su");
    }
    g_phase = prev_phase;
    auto& slot = g_programs[key];
    slot = p;
    return slot.prog ? &slot : nullptr;
}

// ------------------------------------------------------------------ fixed programs (copies, reinterpretation)
const char* kFullscreenVS =
    "#version 330 core\n"
    "void main() { vec2 p = vec2((gl_VertexID << 1) & 2, gl_VertexID & 2); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }\n";

const char* kCopyFS =
    "#version 330 core\n"
    "uniform sampler2D u_src;\nuniform ivec4 u_rect;  // source origin (internal pixels), half\n"
    "out vec4 o;\n"
    "void main() {\n"
    "  ivec2 d = ivec2(gl_FragCoord.xy);\n"
    "  if (u_rect.z != 0) {\n"
    "    // 2x2 box filter over EFB pixels: at internal scale s, average the block's four quadrant centers\n"
    "    vec2 base = vec2(u_rect.xy) + vec2(d) * 2.0;\n"
    "    vec2 sz = vec2(textureSize(u_src, 0));\n"
    "    vec2 c = base + 1.0;\n"
    "    o = texture(u_src, c / sz);\n"
    "  } else {\n"
    "    o = texelFetch(u_src, u_rect.xy + d, 0);\n"
    "  }\n"
    "}\n";

// Encode an EFB texel (RGBA8) as copy format `copy`, then decode it as texture format `tex`, exactly like the
// CPU copy encoder and texture decoder do.
const char* kReinterpretFS =
    "#version 330 core\n"
    "uniform sampler2D u_src;\nuniform ivec4 u_mode;  // copy fmt, tex fmt, intensity\n"
    "out vec4 o;\n"
    "int e4(int v) { return v * 17; }\nint e5(int v) { return (v << 3) | (v >> 2); }\nint e6(int v) { return (v << 2) | (v >> 4); }\n"
    "int e3(int v) { return (v << 5) | (v << 2) | (v >> 1); }\n"
    "void main() {\n"
    "  ivec4 p = ivec4(floor(texelFetch(u_src, ivec2(gl_FragCoord.xy), 0) * 255.0 + 0.5));\n"
    "  int I = u_mode.z != 0 ? clamp((66 * p.r + 129 * p.g + 25 * p.b + 128) / 256 + 16, 0, 255) : p.r;\n"
    "  int v = 0; ivec4 rgba8 = ivec4(0);\n"
    "  switch (u_mode.x) {\n"
    "    case 0: v = I >> 4; break;\n"
    "    case 1: case 8: v = I; break;\n"
    "    case 2: v = ((p.a >> 4) << 4) | (I >> 4); break;\n"
    "    case 7: v = p.a; break;\n"
    "    case 9: v = p.g; break;\n"
    "    case 10: v = p.b; break;\n"
    "    case 3: v = (p.a << 8) | I; break;\n"
    "    case 11: v = (p.g << 8) | p.r; break;\n"
    "    case 12: v = (p.b << 8) | p.g; break;\n"
    "    case 4: v = ((p.r >> 3) << 11) | ((p.g >> 2) << 5) | (p.b >> 3); break;\n"
    "    case 5: v = p.a >= 224 ? (0x8000 | ((p.r >> 3) << 10) | ((p.g >> 3) << 5) | (p.b >> 3))\n"
    "                            : (((p.a >> 5) << 12) | ((p.r >> 4) << 8) | ((p.g >> 4) << 4) | (p.b >> 4)); break;\n"
    "    default: rgba8 = p; break;\n"
    "  }\n"
    "  ivec4 r;\n"
    "  switch (u_mode.y) {\n"
    "    case 0: { int i = e4(v & 15); r = ivec4(i); break; }\n"
    "    case 1: r = ivec4(v & 255); break;\n"
    "    case 2: { int i = e4(v & 15); r = ivec4(i, i, i, e4((v >> 4) & 15)); break; }\n"
    "    case 3: { int i = v & 255; r = ivec4(i, i, i, (v >> 8) & 255); break; }\n"
    "    case 4: r = ivec4(e5((v >> 11) & 31), e6((v >> 5) & 63), e5(v & 31), 255); break;\n"
    "    case 5: if ((v & 0x8000) != 0) r = ivec4(e5((v >> 10) & 31), e5((v >> 5) & 31), e5(v & 31), 255);\n"
    "            else r = ivec4(e4((v >> 8) & 15), e4((v >> 4) & 15), e4(v & 15), e3((v >> 12) & 7)); break;\n"
    "    default: r = rgba8; break;\n"
    "  }\n"
    "  o = vec4(r) / 255.0;\n"
    "}\n";

// ------------------------------------------------------------------ state mapping
GLenum blend_factor(uint32_t f, bool src, bool dst_alpha) {
    switch (f) {
    case 0: return ZERO;
    case 1: return ONE;
    case 2: return src ? DST_COLOR : SRC_COLOR;
    case 3: return src ? ONE_MINUS_DST_COLOR : ONE_MINUS_SRC_COLOR;
    case 4: return SRC1_ALPHA;
    case 5: return ONE_MINUS_SRC1_ALPHA;
    case 6: return dst_alpha ? DST_ALPHA : ONE;
    default: return dst_alpha ? ONE_MINUS_DST_ALPHA : ZERO;
    }
}

const GLenum kLogic[16] = {CLEAR, AND, AND_REVERSE, COPY, AND_INVERTED, NOOP, XOR, OR,
                           NOR, EQUIV, INVERT, OR_REVERSE, COPY_INVERTED, OR_INVERTED, NAND, SET};

void apply_state(const GpuState& st) {
    const DrawCfg& c = st.cfg;
    Enable(CLIP_DISTANCE0); Enable(CLIP_DISTANCE1); Enable(GLenum(CLIP_DISTANCE0 + 2));
    // blending / logic op
    uint32_t bm = c.blend;
    Disable(COLOR_LOGIC_OP);
    if (bm & 1) {
        Enable(BLEND);
        if (bm & (1 << 11)) {
            // dst - src (alpha too, unless constant alpha replaces it)
            BlendEquationSeparate(FUNC_REVERSE_SUBTRACT, c.const_alpha_en ? FUNC_ADD : FUNC_REVERSE_SUBTRACT);
            if (c.const_alpha_en) BlendFuncSeparate(ONE, ONE, ONE, ZERO);
            else BlendFuncSeparate(ONE, ONE, ONE, ONE);
        } else {
            uint32_t sf = (bm >> 8) & 7, df = (bm >> 5) & 7;
            GLenum s = blend_factor(sf, true, c.dst_has_alpha), d = blend_factor(df, false, c.dst_has_alpha);
            BlendEquationSeparate(FUNC_ADD, FUNC_ADD);
            if (c.const_alpha_en) BlendFuncSeparate(s, d, ONE, ZERO);
            else BlendFuncSeparate(s, d, s, d);
        }
    } else {
        Disable(BLEND);
        if (bm & 2) { Enable(COLOR_LOGIC_OP); LogicOp(kLogic[(bm >> 12) & 15]); }
    }
    bool cu = bm & (1 << 3), au = (bm & (1 << 4)) && c.dst_has_alpha;
    ColorMask(cu, cu, cu, au);
    // depth
    if (c.z_enable) {
        Enable(DEPTH_TEST);
        DepthFunc(NEVER + c.z_func);
        DepthMask(c.z_update);
    } else {
        Disable(DEPTH_TEST);
        DepthMask(0);
    }
    // culling: GX front faces are clockwise with y down == positive area in our (row-preserving) window coords
    if (st.cull == 0) Disable(CULL_FACE);
    else {
        Enable(CULL_FACE);
        FrontFace(CCW);
        CullFace(st.cull == 1 ? BACK : st.cull == 2 ? FRONT : FRONT_AND_BACK);
    }
    // scissor
    Enable(SCISSOR_TEST);
    int x0 = std::max(0, c.scissor_x0), y0 = std::max(0, c.scissor_y0);
    int x1 = std::min(EFB_W - 1, c.scissor_x1), y1 = std::min(EFB_H - 1, c.scissor_y1);
    if (x1 < x0 || y1 < y0) Scissor(0, 0, 0, 0);
    else Scissor(SX(x0), SY(y0), SX(x1 + 1) - SX(x0), SY(y1 + 1) - SY(y0));
}

void run_draw(const GpuFrame& f, const GpuCmd& cmd) {
    const GpuState& st = f.states[cmd.state];
    const DrawCfg& c = st.cfg;
    int ntex = int(cmd.ntex);
    Program* p = program_for(c, ntex);
    if (!p) return;
    // Textures first (reinterpretation passes change GL state).
    GLuint tex[8];
    for (int m = 0; m < 8; m++) {
        bool used = false;
        for (int s = 0; s < c.stages; s++) used |= c.st[s].tex_enabled && c.st[s].texmap == m;
        for (int i = 0; i < c.nind; i++) used |= c.ind_map[i] == m;
        tex[m] = used ? texture_for(c.tex[m]) : g_white;
    }
    UseProgram(p->prog);
    apply_state(st);
    for (int m = 0; m < 8; m++) {
        ActiveTexture(TEXTURE0 + GLenum(m));
        BindTexture(TEXTURE_2D, tex[m]);
        uint32_t ws = std::min<uint32_t>(c.wrap_s[m], 2), wt = std::min<uint32_t>(c.wrap_t[m], 2);
        BindSampler(GLuint(m), sampler_for(c.min_filter[m], c.linear[m], ws, wt));
    }
    float vp0[4] = {st.vp[0], st.vp[1], st.vp[2], 0}, vp1[4] = {st.vp[3] - 342.f - c.xoff, st.vp[4] - 342.f - c.yoff, st.vp[5], 0};
    Uniform4fv(p->u_vp0, 1, vp0);
    Uniform4fv(p->u_vp1, 1, vp1);
    float efb[2] = {float(EFB_W), float(EFB_H)};
    Uniform2fv(p->u_efb, 1, efb);
    GLint reg[16], konst[16];
    for (int i = 0; i < 4; i++)
        for (int k = 0; k < 4; k++) { reg[i * 4 + k] = c.tev_reg[i][k]; konst[i * 4 + k] = c.konst[i][k]; }
    Uniform4iv(p->u_reg, 4, reg);
    Uniform4iv(p->u_konst, 4, konst);
    GLint aref[4] = {GLint(c.alpha_cmp & 0xFF), GLint((c.alpha_cmp >> 8) & 0xFF), 0, 0};
    Uniform4iv(p->u_aref, 1, aref);
    float sts[32];
    for (int s = 0; s < 16; s++) {
        float tw = 1.f, th = 1.f;
        if (s < c.stages) {
            const Texture* t = c.tex[c.st[s].texmap];
            if (t && t->w) { tw = float(t->w); th = float(t->h); }
            int tc = c.st[s].texcoord & 7;
            sts[s * 2] = c.su_s[tc] / tw;
            sts[s * 2 + 1] = c.su_t[tc] / th;
        } else {
            sts[s * 2] = sts[s * 2 + 1] = 0;
        }
    }
    Uniform2fv(p->u_stscale, 16, sts);
    if (p->u_calpha >= 0) Uniform1f(p->u_calpha, float(c.const_alpha) / 255.f);
    if (p->u_indmtx >= 0) {
        GLint im[24];
        for (int m = 0; m < 3; m++) {
            const int16_t* x = c.ind_mtx[m];
            GLint* o = im + m * 8;
            o[0] = x[0]; o[1] = x[2]; o[2] = x[4]; o[3] = c.ind_shift[m];
            o[4] = x[1]; o[5] = x[3]; o[6] = x[5]; o[7] = 0;
        }
        Uniform4iv(p->u_indmtx, 6, im);
    }
    if (p->u_texsz >= 0) {
        float ts[16];
        for (int m = 0; m < 8; m++) {
            const Texture* t = c.tex[m];
            ts[m * 2] = t && t->w ? float(t->w) : 1.f;
            ts[m * 2 + 1] = t && t->h ? float(t->h) : 1.f;
        }
        Uniform2fv(p->u_texsz, 8, ts);
    }
    if (p->u_su >= 0) {
        float su[16];
        for (int t = 0; t < 8; t++) { su[t * 2] = c.su_s[t]; su[t * 2 + 1] = c.su_t[t]; }
        Uniform2fv(p->u_su, 8, su);
    }
    if (p->u_fog >= 0) {
        float fog[4] = {c.fog_a, c.fog_c, float(c.fog_bmag), float(c.fog_bshift)};
        Uniform4fv(p->u_fog, 1, fog);
        GLint fc[4] = {c.fog_color[0], c.fog_color[1], c.fog_color[2], 0};
        Uniform4iv(p->u_fogcolor, 1, fc);
    }
    {   // depth of the near (z = -w) and far (z = 0) planes for this viewport, quantized like the 24-bit z buffer
        auto q = [](double d) { return float(std::floor(std::clamp(d, 0.0, 1.0) * 16777215.0 + 0.5) / 16777215.0); };
        float zr[2] = {q((double(st.vp[5]) - double(st.vp[2])) / 16777216.0), q(double(st.vp[5]) / 16777216.0)};
        Uniform2fv(p->u_zrange, 1, zr);
    }
    // vertex attributes
    const uint8_t* base = reinterpret_cast<const uint8_t*>(uintptr_t(cmd.vtx_off));
    GLsizei stride = GLsizei(cmd.stride);
    VertexAttribPointer(0, 4, FLOAT, 0, stride, base);
    VertexAttribPointer(1, 4, UNSIGNED_BYTE, 1, stride, base + 16);
    VertexAttribPointer(2, 4, UNSIGNED_BYTE, 1, stride, base + 20);
    for (int i = 0; i < 8; i++) {
        if (i < ntex) { EnableVertexAttribArray(GLuint(3 + i)); VertexAttribPointer(GLuint(3 + i), 3, FLOAT, 0, stride, base + 24 + 12 * i); }
        else DisableVertexAttribArray(GLuint(3 + i));
    }
    DrawElements(TRIANGLES, GLsizei(cmd.idx_count), UNSIGNED_INT,
                 reinterpret_cast<const void*>(uintptr_t(cmd.idx_first) * 4));
    g_stats.draws++;
    g_stats.triangles += cmd.idx_count / 3;
}

void run_clear(const GpuCmd& cmd) {
    Enable(SCISSOR_TEST);
    Scissor(SX(cmd.x), SY(cmd.y), SX(cmd.x + cmd.w) - SX(cmd.x), SY(cmd.y + cmd.h) - SY(cmd.y));
    Disable(COLOR_LOGIC_OP);
    GLbitfield mask = 0;
    if (cmd.cu || cmd.au) {
        ColorMask(cmd.cu, cmd.cu, cmd.cu, cmd.au);
        ClearColor(float(cmd.color & 255) / 255.f, float((cmd.color >> 8) & 255) / 255.f,
                   float((cmd.color >> 16) & 255) / 255.f, float(cmd.color >> 24) / 255.f);
        mask |= COLOR_BUFFER_BIT;
    }
    if (cmd.zu) {
        DepthMask(1);
        ClearDepth(double(cmd.z) / 16777215.0);
        mask |= DEPTH_BUFFER_BIT;
    }
    if (mask) Clear(mask);
}

GLint g_copy_u_src = -1;

void run_copy_tex(const GpuCmd& cmd) {
    int w = std::max(1, SX(std::max(1, cmd.out_w))), h = std::max(1, SY(std::max(1, cmd.out_h)));
    RT t = rt_acquire(w, h);
    BindFramebuffer(FRAMEBUFFER, t.fbo);
    Viewport(0, 0, w, h);
    pass_state();
    UseProgram(g_copy_prog);
    GLint rect[4] = {SX(cmd.x), SY(cmd.y), cmd.half ? 1 : 0, 0};  // source origin in internal pixels
    Uniform4iv(g_copy_u_rect, 1, rect);
    ActiveTexture(TEXTURE0);
    BindTexture(TEXTURE_2D, g_efb_color);
    BindSampler(0, 0);
    DrawArrays(TRIANGLES, 0, 3);
    auto old = g_copies.find(cmd.copy_id);
    if (old != g_copies.end()) rt_release(old->second.rt);
    g_copies[cmd.copy_id] = {t, g_frame_no};
    BindFramebuffer(FRAMEBUFFER, g_efb_fbo);
    Viewport(0, 0, SX(EFB_W), SY(EFB_H));
    g_stats.tex_copies++;
}

void run_copy_xfb(const GpuCmd& cmd) {
    int w = SX(cmd.x + cmd.w) - SX(cmd.x), h = SY(cmd.y + cmd.h) - SY(cmd.y);
    if (w != g_out_w || h != g_out_h) {
        if (g_out_tex) { DeleteTextures(1, &g_out_tex); DeleteFramebuffers(1, &g_out_fbo); }
        g_out_tex = make_tex(w, h, RGBA8, RGBA, UNSIGNED_BYTE, nullptr, true);
        g_out_fbo = fbo_for(g_out_tex);
        g_out_w = w; g_out_h = h;
    }
    pass_state();
    BindFramebuffer(READ_FRAMEBUFFER, g_efb_fbo);
    BindFramebuffer(DRAW_FRAMEBUFFER, g_out_fbo);
    BlitFramebuffer(SX(cmd.x), SY(cmd.y), SX(cmd.x) + w, SY(cmd.y) + h, 0, 0, w, h,
                    COLOR_BUFFER_BIT, NEAREST);
    // The TV shows RGB only: make the output opaque (EFB alpha is often 0, and the port draws the image with
    // alpha blending, which would make it invisible).
    BindFramebuffer(FRAMEBUFFER, g_out_fbo);
    ColorMask(0, 0, 0, 1);
    ClearColor(0, 0, 0, 1);
    Clear(COLOR_BUFFER_BIT);
    ColorMask(1, 1, 1, 1);
    BindFramebuffer(FRAMEBUFFER, g_efb_fbo);
    g_out_wide = g_wide;
    g_out_seq++;
}

void execute(GpuFrame& f) {
    auto t0 = std::chrono::steady_clock::now();
    if (f.wide != g_wide) { g_wide = f.wide; create_efb(); }  // gameplay <-> front end: anamorphic EFB width
    g_frame_no++;
    g_phase_frame = g_frame_no;
    g_phase_ncmds = uint32_t(f.cmds.size());
    g_phase = "upload vertices";
    BindFramebuffer(FRAMEBUFFER, g_efb_fbo);
    Viewport(0, 0, SX(EFB_W), SY(EFB_H));
    Enable(DEPTH_CLAMP);
    Enable(CLIP_DISTANCE0); Enable(CLIP_DISTANCE1); Enable(GLenum(CLIP_DISTANCE0 + 2));
    BindVertexArray(g_vao);
    BindBuffer(ARRAY_BUFFER, g_vbo);
    BufferData(ARRAY_BUFFER, GLsizeiptr(f.vtx.size()), f.vtx.data(), STREAM_DRAW);
    BindBuffer(ELEMENT_ARRAY_BUFFER, g_ibo);
    BufferData(ELEMENT_ARRAY_BUFFER, GLsizeiptr(f.idx.size() * 4), f.idx.data(), STREAM_DRAW);
    EnableVertexAttribArray(0); EnableVertexAttribArray(1); EnableVertexAttribArray(2);
    static const long dump_frame = getenv("SSNE_GPU_DUMP_FRAME") ? atol(getenv("SSNE_GPU_DUMP_FRAME")) : -1;
    bool has_copy = false;
    for (const GpuCmd& c : f.cmds) has_copy |= c.type == GpuCmd::COPY_TEX;
    g_dumping = long(g_frame_no) == dump_frame || (g_dump_req && (has_copy || g_frame_no % 300 == 0));
    if (g_dumping) {
        if (g_dump_dir.empty()) g_dump_dir = "/tmp/claude-0";
        g_dump_req = false;
        g_dump_n = 0;
        g_dump_log = fopen((g_dump_dir + "/frame.txt").c_str(), "w");
        if (g_dump_log) fprintf(g_dump_log, "frame %llu, scale %d, %zu commands, renderer %s\n", (unsigned long long)g_frame_no, g_scale,
                                f.cmds.size(), g_info.c_str());
    }
    for (const GpuCmd& c : f.cmds) {
        if (g_dumping && g_dump_log) {
            if (c.type == GpuCmd::DRAW) {
                const GpuState& gs = f.states[c.state];
                const DrawCfg& d = gs.cfg;
                fprintf(g_dump_log, "draw tris=%u ntex=%u stages=%d blend=%06X z=%d/%u/%d acmp=%06X cmask=%08X dsta=%d calpha=%d/%d scissor=%d,%d-%d,%d off=%.0f,%.0f vp=%.1f,%.1f,%.1f,%.1f,%.1f,%.1f cull=%u\n",
                        c.idx_count / 3, c.ntex, d.stages, d.blend, d.z_enable, d.z_func, d.z_update, d.alpha_cmp, d.write_mask,
                        d.dst_has_alpha, d.const_alpha_en, d.const_alpha, d.scissor_x0, d.scissor_y0, d.scissor_x1, d.scissor_y1,
                        d.xoff, d.yoff, gs.vp[0], gs.vp[1], gs.vp[2], gs.vp[3], gs.vp[4], gs.vp[5], gs.cull);
                for (int si = 0; si < d.stages; si++) {
                    const StageCfg& st = d.st[si];
                    fprintf(g_dump_log, "   s%d c=%06X a=%06X tex=%d map=%d tc=%d ras=%d", si, st.cenv, st.aenv, st.tex_enabled, st.texmap,
                            st.texcoord, st.ras_chan);
                    if (st.tex_enabled) {
                        const Texture* t = d.tex[st.texmap];
                        if (t) fprintf(g_dump_log, " [%dx%d id %llu copy %lld fmt %u->%u minf %u mag %d wrap %u/%u mips %zu su %.0f/%.0f]", t->w, t->h,
                                       (unsigned long long)t->id, (long long)t->efb_copy, t->copy_fmt, t->tex_fmt, d.min_filter[st.texmap],
                                       d.linear[st.texmap], d.wrap_s[st.texmap], d.wrap_t[st.texmap], t->mips.size(),
                                       d.su_s[st.texcoord & 7], d.su_t[st.texcoord & 7]);
                        else fprintf(g_dump_log, " [no texture]");
                    }
                    fprintf(g_dump_log, "\n");
                }
                if (c.idx_count <= 6)
                    for (uint32_t vi = 0; vi < c.vcount; vi++) {
                        float pp[4], tc[3] = {0, 0, 0};
                        memcpy(pp, f.vtx.data() + c.vtx_off + vi * c.stride, 16);
                        const uint8_t* col = f.vtx.data() + c.vtx_off + vi * c.stride + 16;
                        if (c.ntex) memcpy(tc, f.vtx.data() + c.vtx_off + vi * c.stride + 24, 12);
                        fprintf(g_dump_log, "   v%u clip=(%.3f %.3f %.6f %.6f) depth=%.7f col0=%u,%u,%u,%u tex0=(%.3f %.3f %.3f)\n", vi, pp[0],
                                pp[1], pp[2], pp[3], (pp[2] / pp[3] * gs.vp[2] + gs.vp[5]) / 16777216.f, col[0], col[1], col[2], col[3],
                                tc[0], tc[1], tc[2]);
                    }
            } else {
                fprintf(g_dump_log, "%s rect=%d,%d %dx%d color=%08X z=%06X cu/au/zu=%d%d%d half=%d copy_id=%llu out=%dx%d\n",
                        c.type == GpuCmd::CLEAR ? "CLEAR" : c.type == GpuCmd::COPY_TEX ? "COPY_TEX" : "COPY_XFB", c.x, c.y, c.w, c.h,
                        c.color, c.z, c.cu, c.au, c.zu, c.half, (unsigned long long)c.copy_id, c.out_w, c.out_h);
                dump_fbo(g_efb_fbo, SX(EFB_W), SY(EFB_H), c.type == GpuCmd::CLEAR ? "efb_before_clear" : "efb_before_copy");
                dump_depth("efb_depth");
                BindFramebuffer(FRAMEBUFFER, g_efb_fbo);
            }
            fflush(g_dump_log);
        }
        g_phase_cmd = uint32_t(&c - f.cmds.data());
        g_phase = c.type == GpuCmd::DRAW ? "draw" : c.type == GpuCmd::CLEAR ? "clear" : c.type == GpuCmd::COPY_TEX ? "copy" : "display copy";
        switch (c.type) {
        case GpuCmd::DRAW: run_draw(f, c); break;
        case GpuCmd::CLEAR: run_clear(c); break;
        case GpuCmd::COPY_TEX:
            run_copy_tex(c);
            if (g_dumping) { auto& ct = g_copies[c.copy_id].rt; dump_fbo(ct.fbo, ct.w, ct.h, "copy_texture"); BindFramebuffer(FRAMEBUFFER, g_efb_fbo); }
            break;
        case GpuCmd::COPY_XFB:
            run_copy_xfb(c);
            if (g_dumping) { dump_fbo(g_out_fbo, g_out_w, g_out_h, "output"); BindFramebuffer(FRAMEBUFFER, g_efb_fbo); }
            break;
        }
    }
    if (g_dumping) {
        if (g_dump_log) { fprintf(g_dump_log, "end of frame\n"); fclose(g_dump_log); g_dump_log = nullptr; }
        g_dumping = false;
        log_message("[gpu] frame " + std::to_string(g_frame_no) + " captured to " + g_dump_dir);
    }
    // Leave a neutral state for whoever draws next (the port's UI).
    for (int m = 0; m < 8; m++) BindSampler(GLuint(m), 0);
    ActiveTexture(TEXTURE0);
    Disable(DEPTH_CLAMP);
    Disable(CLIP_DISTANCE0); Disable(CLIP_DISTANCE1); Disable(GLenum(CLIP_DISTANCE0 + 2));
    Disable(COLOR_LOGIC_OP); Disable(SCISSOR_TEST); Disable(DEPTH_TEST); Disable(CULL_FACE); Disable(BLEND);
    ColorMask(1, 1, 1, 1);
    DepthMask(1);
    BindVertexArray(0);
    BindFramebuffer(FRAMEBUFFER, 0);
    UseProgram(0);
    evict();
    GLenum e = (g_frame_no % 120 == 1) ? GetError() : 0;  // glGetError can force a driver sync: check rarely
    if (e) {
        static int reported = 0;
        if (reported++ < 10) {
            char buf[96];
            snprintf(buf, sizeof(buf), "[gpu] OpenGL error 0x%04X in frame %llu", e, (unsigned long long)g_frame_no);
            log_message(buf);
        }
        while (GetError()) {}
    }
    g_stats.frames++;
    g_stats.frame_ms = std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now() - t0).count();
    g_max_frame_ms = std::max(g_max_frame_ms, g_stats.frame_ms);
    if (g_stats.frame_ms > 250) {
        char buf[160];
        snprintf(buf, sizeof(buf), "[gpu] slow frame %llu: %.0f ms (%zu commands, %zu vertices bytes)",
                 (unsigned long long)g_frame_no, g_stats.frame_ms, f.cmds.size(), f.vtx.size());
        log_message(buf);
    }
    g_phase = "idle";
}

} // namespace

void gx_use_gpu(bool on) {
    g_gpu_mode = on;
    gx::gpu_set_enabled(on);
}
bool gx_gpu_active() { return g_gpu_mode; }

bool gpu_renderer_init(void* (*getproc)(const char*), int scale, std::string& err) {
    const char* missing = nullptr;
    if (!gl::load(getproc, &missing)) { err = std::string("OpenGL function missing: ") + (missing ? missing : "?"); return false; }
    g_scale = std::clamp(scale, 1, 8);
    g_info = std::string(reinterpret_cast<const char*>(GetString(RENDERER))) + " | " +
             reinterpret_cast<const char*>(GetString(VERSION));
    GenVertexArrays(1, &g_vao);
    GenBuffers(1, &g_vbo);
    GenBuffers(1, &g_ibo);
    uint32_t white = 0xFFFFFFFFu;
    g_white = make_tex(1, 1, RGBA8, RGBA, UNSIGNED_BYTE, &white);
    g_copy_prog = link(kFullscreenVS, kCopyFS);
    g_reint_prog = link(kFullscreenVS, kReinterpretFS);
    if (!g_copy_prog || !g_reint_prog) { err = "failed to build GPU renderer shaders"; return false; }
    UseProgram(g_copy_prog);
    Uniform1i(GetUniformLocation(g_copy_prog, "u_src"), 0);
    g_copy_u_rect = GetUniformLocation(g_copy_prog, "u_rect");
    UseProgram(g_reint_prog);
    Uniform1i(GetUniformLocation(g_reint_prog, "u_src"), 0);
    g_reint_u_mode = GetUniformLocation(g_reint_prog, "u_mode");
    UseProgram(0);
    GenFramebuffers(1, &g_tmp_fbo);
    create_efb();
    BindFramebuffer(FRAMEBUFFER, 0);
    g_ready = true;
    fprintf(stdout, "[gpu] renderer: %s, internal resolution %dx (%dx%d)\n", g_info.c_str(), g_scale, SX(EFB_W), SY(EFB_H));
    return true;
}

bool gpu_renderer_run(int max_frames) {
    if (!g_ready) return false;
    uint64_t before = g_out_seq;
    for (int i = 0; i < max_frames; i++) {
        g_phase = "take frame";
        auto f = gx::gpu_take_frame();
        g_phase = "idle";
        if (!f) break;
        execute(*f);
    }
    return g_out_seq != before;
}

void gpu_renderer_set_scale(int scale) {
    scale = std::clamp(scale, 1, 8);
    if (scale == g_scale || !g_ready) { g_scale = scale; return; }
    g_scale = scale;
    create_efb();
    BindFramebuffer(FRAMEBUFFER, 0);
}
int gpu_renderer_scale() { return g_scale; }

void gpu_renderer_set_widescreen(float) {}  // per frame now (GpuFrame::wide)

GpuOutput gpu_renderer_output() { return {g_out_tex, g_out_w, g_out_h, g_out_seq, g_out_wide}; }

bool gpu_renderer_read_output(std::vector<uint32_t>& rgba, int& w, int& h) {
    if (!g_out_tex) return false;
    w = g_out_w; h = g_out_h;
    rgba.resize(size_t(w) * h);
    BindFramebuffer(FRAMEBUFFER, g_out_fbo);
    PixelStorei(PACK_ALIGNMENT, 4);
    ReadPixels(0, 0, w, h, RGBA, UNSIGNED_BYTE, rgba.data());
    BindFramebuffer(FRAMEBUFFER, 0);
    return true;
}

std::string gpu_renderer_info() { return g_info; }

void gpu_renderer_request_dump(const std::string& dir) { g_dump_dir = dir; g_dump_req = true; }

std::string gpu_renderer_phase() {
    char buf[160];
    snprintf(buf, sizeof(buf), "%s (frame %llu, command %u of %u)", g_phase.load(), (unsigned long long)g_phase_frame.load(),
             g_phase_cmd.load(), g_phase_ncmds.load());
    return buf;
}

double gpu_renderer_take_max_frame_ms() { double m = g_max_frame_ms; g_max_frame_ms = 0; return m; }
GpuStats gpu_renderer_stats() { return g_stats; }

} // namespace ssne
