// A recorded GX frame for the GPU renderer (produced on the guest thread, executed on the render thread).
#pragma once
#include <cstdint>
#include <memory>
#include <unordered_set>
#include <vector>

#include "gx_internal.h"

namespace ssne::gx {

struct GpuState {
    DrawCfg cfg;       // TEV / blend / depth / scissor snapshot (padding zeroed: compared with memcmp)
    float vp[6];       // XF viewport: scale x, y, z, offset x, y, z
    uint32_t cull;     // GENMODE cull mode
};

struct GpuCmd {
    enum Type : uint8_t { DRAW, CLEAR, COPY_TEX, COPY_XFB } type;
    // DRAW: vertex block at vtx_off (stride = 24 + 12 * ntex bytes: pos f32x4, color0/1 u8x4, texcoords f32x3),
    //       indices [idx_first, idx_first + idx_count) relative to the block
    uint32_t state, vtx_off, stride, ntex, vcount, idx_first, idx_count;
    // CLEAR / COPY_*: EFB rectangle
    int x, y, w, h;
    // CLEAR
    uint32_t color, z;
    bool cu, au, zu;
    // COPY_TEX
    bool half;
    uint64_t copy_id;
    int out_w, out_h;
};

struct GpuFrame {
    uint64_t seq = 0;
    float wide = 1.0f;  // widescreen factor this frame was rendered with
    std::vector<GpuCmd> cmds;
    std::vector<GpuState> states;
    std::vector<uint8_t> vtx;
    std::vector<uint32_t> idx;
    std::vector<std::shared_ptr<const Texture>> textures;  // keeps decoded textures alive until executed
    std::unordered_set<const Texture*> kept;
};

std::unique_ptr<GpuFrame> gpu_take_frame();  // render thread: next recorded frame, or null
size_t gpu_frames_queued();
void gpu_set_enabled(bool on);

} // namespace ssne::gx
