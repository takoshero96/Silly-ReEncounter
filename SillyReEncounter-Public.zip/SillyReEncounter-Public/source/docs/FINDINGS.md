# Technical findings — Serious Sam: Next Encounter (GameCube, USA Rev 1)

Everything below comes from the disc's system files (boot.bin, bi2.bin, apploader.img, fst.bin, main.dol).

## Disc
| Field | Value |
|---|---|
| Game ID | **G3BE9G** (G = GameCube, 3B = title, E = USA, 9G = Global Star / Take-Two) |
| Disc revision | 1 |
| Boot title | `Serious Sam` |
| Game build string | `Build FINAL.107  (Jan 22 2004 @ 12:04:50)` |
| Dolphin SDK | OS release build `Sep  5 2002 05:32:39 (0x2301)`, apploader dated 2002/09/05 |
| main.dol offset | 0x0001EC00 |
| FST | 0x0028E500, 3,554 bytes, 135 entries |

## main.dol (2,554,080 bytes)
| Section | Address | Size |
|---|---|---|
| T0 (init) | 80003100 | 0x3A0 |
| T1 (.text) | 800034A0 | 0x1DD8A0 (≈1.87 MB, 489k instructions) |
| D0–D4 | 801E0D40 – 802DDB40 | ctors/dtors/rodata/data/sdata |
| BSS | 8026F6A0 | 0x6D124 |
| Entry | 80003100 (`__start`) | |

Source paths in the binary (`C:/SeriousSam/src/game/system/Engine/engine.cpp`, `xforms.cpp`) and class names
(`cWickerManAI`, `CcSeriousJeep`, `CcSeriousCombine`) show a C++ engine built with CodeWarrior. The game code
starts after the C runtime. Dolphin SDK libraries sit near the end of .text (≈ 801B0000–801E0000).

## File formats on disc (targets for native loaders)
| Ext | Contents | Notes |
|---|---|---|
| `.ssw` | Levels (`Levels/`, 60 files, 4.5–8.5 MB each) | Climax world format; loaded by the engine itself. No PC loader needed if the recompiled code reads it |
| `.ssg` | Packed resources (`Data.ssg`, `FrontEnd.ssg`, multiplayer skins) | Same |
| `.sst` | Textures (loading screens, title) | GX texture formats (CMPR/I8/RGB5A3…) → decoded by the GX layer |
| `.tdb` | Localized text (English USA/EUR, French, German) | |
| `.cfg` | Plain-text tuning files (`base.cfg`, `MinionStats.cfg`, …) | Moddable |
| `.spd/.spt` | Sound bank (`sfxbank1`), DSP-ADPCM | Needs DSP-ADPCM decoding (AX HLE) |
| `StreamData.dat` | 111 MB streamed audio | Streamed via ARAM/DVD |
| `.bik` | 35 Bink videos (FMVs, intro logos) | Bink 1, decodable with FFmpeg's `bink` decoder |
| `opening.bnr` | GameCube banner | Can serve as the launcher icon |

## Recompilation results
* Function discovery: entry + 3,978 `bl` targets + 257 code-address constants + 3,658 data pointers (vtables,
  callbacks) → **7,919 functions**. **23 of 23** `bctr` switch jump tables resolved.
* **100%** of executable instructions translated. The 23 "unimplemented" words are zero padding.
* The generated C++ (~25 MB) compiles cleanly with GCC 13 and Clang 19.

## Symbols
608 functions named automatically and by hand. See [SYMBOLS.md](SYMBOLS.md). SDK build confirmed from the game's own
log: every library reports `release build: Sep  5 2002 (0x2301)`. `OSMutex`/`OSMessage` aren't linked, and neither is `DVDOpen`.

## Boot log (headless runner, with the native OSReport)
```
<< Dolphin SDK - EXI ... SI ... >>
Dolphin OS $Revision: 58 $.  Kernel built : Sep  5 2002 05:32:39
Console Type : Retail 1   Memory 24 MB   Arena : 0x802edb80 - 0x81780000
<< Dolphin SDK - OS ... DVD ... >>
Startup Memory Free 21570688
<< Dolphin SDK - VI ... PAD ... >>
Microallocator handling 479k
<< Dolphin SDK - AR ... >>            <- stops in ARInit/__ARChecksize (ARAM size probe)
```

## Current state: playable-looking first level (software renderer)
With the software GX renderer and SI controller emulation, the recompiled game shows everything from boot to gameplay:
"Licensed by Nintendo" → memory-card check (no card: "Continue Without Save") → Global Star/Climax/Croteam logos and
Bink FMVs (decoded by the game's own recompiled Bink code) → main menu with 3D Sam → player/level/difficulty select →
intro cutscene with subtitles → **gameplay in "Incident at the Arena"** (Colosseum, HUD, weapon).

Rendering facts learned from the game:
* Each gameplay frame: scene → EFB-to-texture copy (RGB565) + clear → half-res GB8 copy → scene texture redrawn as a
  full-screen quad → more geometry → HUD → display copy. ~13k triangles, ~0.94 M pixels written per frame.
* That redraw uses **manual texcoord scaling** (`GXSetTexCoordScaleManually`): texcoords are in texels and the SU scale
  registers (BP 0x30-0x3F) are 1. Honoring those registers fixed a flat-color screen.
* Menus navigate with the **analog stick**, not the D-pad.
* Performance: game code alone runs at a locked 60 fps; the software rasterizer costs ~110 ms/frame single-threaded
  on the build sandbox (≈87 ns/pixel). **On the user's Windows PC the game build runs at a locked 60 fps** in gameplay.
* "Failed to find file textures/… / Models/…" log lines are normal: the game probes for loose files that aren't on
  the disc and falls back to the copies packed in its .ssg archives.

## Audio (AX HLE)
* AX microcode: CRC **0x07F88145** (HashEctor over the 0x1F20-byte ucode at 0x802693C0), the standard GameCube AX
  whose parameter block includes the low-pass filter. Every 5 ms the AX library sends `0xBABE0000|size` + a command
  list address; the DSP replies `DSP_YIELD` after writing 160 stereo frames (R,L big-endian s16) to RAM.
* AI DMA: 640-byte buffers (5 ms at 32 kHz), double-buffered; the next buffer is programmed from the AIDINT handler.
* Voice types seen: menu/gameplay **music** = 6 DSP-ADPCM stream voices (`is_stream` = 1, ~1 s ARAM ring buffers
  refilled from `StreamData.dat`, no SRC, mixed as 3 L/R pairs with envelope cross-fades); **Bink FMV audio** = 2 PCM16
  looping voices at ratio 0x1607B (44.1 → 32 kHz); **sound effects** = DSP-ADPCM one-shots from `sfxbank1.spd` in ARAM.
* The IPL SRAM isn't emulated, which made `OSGetSoundMode` report mono (every voice mixed to the center). It is
  replaced natively and reports stereo.

## GPU renderer
* Per gameplay frame: ~50 batches after merging identical states, 2 EFB→texture copies (RGB565 scene copy
  redrawn as a full-screen quad; half-res GB8 copy), ~17 distinct TEV programs over a whole session.
* The scene-copy quad is drawn **exactly on the near plane** (clip z = −w) with depth test LEQUAL and no update,
  against scene geometry that was itself clipped by the near plane. The software clipper keeps on-plane geometry
  (it only clips distances < 0) and the depths tie. On the GPU, clip distances need a small tolerance and fragment
  depth is snapped to the viewport's near/far plane when within a few 24-bit ulps, so ties resolve like hardware.
* Build 6 showed black intro/gameplay on NVIDIA (RTX 4060) but not on Mesa: the internal copy/reinterpretation
  passes ran with `GL_CLIP_DISTANCE0-2` enabled while their shaders don't write `gl_ClipDistance` (undefined
  behavior: NVIDIA culled the passes, so every EFB copy the game redraws its scene from came out empty).
* Black gameplay/cutscenes on NVIDIA (builds 6-9) turned out to be presentation, not rendering (found with the F9
  capture): the EFB alpha is 0 in those scenes and the GPU output kept it, so the port's alpha-blended image was
  invisible. The software path always forced alpha to 255. The display copy output is now opaque.
  **Confirmed fixed on the user's RTX 4060 (build 10).**
* Verification method: `ssne-headless --gpu` runs the GL path headlessly (surfaceless EGL / Mesa llvmpipe) and dumps
  frames; `SSNE_GPU_DUMP_FRAME=n` dumps the GPU EFB at every copy/clear of frame n with a draw log, to compare with
  the software renderer's `SSNE_GX_TRACE_FRAME` dumps.

## Widescreen
* HUD anchoring (fixed after build 15): the game draws 2D text one glyph per draw, so anchoring each draw to
  the nearest screen edge by position scattered letters of pause-menu and message text. 2D draws are now scaled
  around the center (original 4:3 layout) unless they touch a screen edge (|x| >= 0.97), which stay on that edge.
  Debug: `SSNE_GX_TRACE_AT=<seconds>` traces the next frame (software renderer), now with ORTHO/persp and x/y range.
* Every camera projection (menus and gameplay) comes from one camera function (`8014C090`) calling the SDK's
  `C_MTXPerspective` (801BA874) three times plus `C_MTXLightPerspective` (801BA5EC) with an aspect computed from the
  viewport (1.429 in game, fovY 42° in menus, 63° in gameplay). The first-person weapon uses a separate projection
  from `8014CDF0`, which only runs during gameplay; that is the gameplay detector.
* Widening the aspect in the SDK function is enough: the engine's culling follows the matrix (objects at the new
  edges render at 21:9).
* Front-end screens place 3D models inside 2D layouts, so they must stay 4:3.

## Player look (mouse aim)
* Found by RAM snapshots while turning (headless `--dump-ram`, `CLEFT/CRIGHT/CUP/CDOWN`): the player object
  (global pointer at 802D8948 -> e.g. 8133C6A0) holds view yaw at +0x290 (radians, fmod 2 pi, + = right) and pitch
  at +0x294 (radians, + = down; limits [+0x194]->+0x24 and [+0x198]->+0x24 in degrees, +/-75 in level 1). The camera
  object keeps a copy (yaw +8, pitch +0xC, then its rotation matrix).
* 800BFCA4 (once per gameplay frame, r3 = player, f1/f2 = stick, f3 = dt) integrates the C-stick: yaw rate grows with
  the square of the deflection (the "acceleration" feel), pitch has an invert flag ([+0x264]->+0x1C) and an
  optional auto-level ([+0x268]->+0x1C). Mouse aim runs it unchanged, then adds the mouse rotation and re-clamps.
  Headless `--aim T:YAW:PITCH` verified exact yaw deltas and pitch clamping.

## Frame pacing
* The main loop (80155638) gets its time step from 8015544C: OSGetTick delta in seconds, replaced by 1/59.94 when
  < 0 or > 1.5 s, then the median of the last 5 values. Game logic is therefore frame-rate independent.
* CcEngine::Flip (801183F0) calls VIWaitForRetrace (8011855C) only if no retrace happened since the previous flip
  (flag set by the VI post-retrace callback 8011731C, which also reads the pads): a 59.94 fps cap.
* Frame limit: the Flip wait is skipped when the limit is not 60, and frames are paced on the host clock at each
  display copy. Headless test (`--norender 97 --fps N`, walking forward 4 s): 60, 141 and ~1350 fps all end at the
  same spot, so movement scales with real time.
* Debug: `SSNE_TRACE_CALLS=addr,...` counts calls per second and prints guest backtraces (pass-through hooks).

## Indirect texturing
* Every gameplay frame the scene copy is redrawn as a full-screen quad with one indirect stage (IREF map 1 /
  coord 1, IND_CMD 0x000270: 8-bit, bias S/T/U, matrix 0 = swap s/t at 0.25). The indirect map is a 320x224 IA8
  EFB copy that is flat 127 (no distortion) until effects draw into it: a screen-space distortion buffer.
* Heat haze/refraction sprites (e.g. minigun muzzle while firing) use a 128x128 CMPR offset texture with matrix
  scale 12 (offsets of a few texels).
* Headless runner: `--press NAME@t:dur` holds an input for `dur` seconds; `CLEFT/CRIGHT` drive the C-stick and R/L
  also set the analog triggers (needed to fire). `SSNE_TRACE_IND=1` logs indirect state per frame, `SSNE_NO_IND=1`
  disables indirect texturing for A/B comparisons.

## Audio resampling
* Voices seen in play (`SSNE_TRACE_AX=1` prints src type and coef select): sound effects are DSP-ADPCM at 32 kHz with
  src type 2 (no conversion); music streams are PCM16 at 44.1 kHz (ratio 0x1607B) with src type 1 (linear). Src type
  0 (polyphase) is rare (a couple of ratio-1.0 voices). So on hardware the music is linearly interpolated from
  44.1 to 32 kHz: roughly -2 dB at 13-15 kHz and aliasing near 16 kHz.
* High-quality mode (default, `SSNE_AUDIO_ORIGINAL=1` / headless `--audio-original` turns it off): 64-tap Kaiser
  sinc (beta 7), 256 phases with linear phase interpolation, cutoff `0.5*min(1,1/ratio) - 0.034` cycles/input
  sample: flat to ~13.5 kHz, -45 dB at 16 kHz for the 44.1 kHz music. The host keeps 128 samples of history per
  parameter block and a 32-sample delay (1 ms) for lookahead; PB_LAST still holds the newest four samples and a
  mismatch (voice restarted) resets the history. Measured on the title music: +2 dB at 13-15 kHz, 15-16 kHz
  aliasing -15 dB, same levels otherwise; ~0 CPU cost.

## Compressed disc images (launcher)
* `libgc` reads CISO, GCZ, WIA and RVZ through a `BlobReader` that presents the plain image, so verification and
  extraction are unchanged. The decoders are built in (no zlib/zstd/liblzma/bzip2 dependency): inflate, zstd
  (RFC 8878), LZMA/LZMA2 and bzip2, each checked byte-exact against the reference encoders (234 vectors) and fuzzed
  under ASan/UBSan.
* RVZ "packed" chunks replace disc padding with 68-byte seeds for Nintendo's lagged-Fibonacci junk generator
  (K=521, J=32); the reader regenerates it, so an RVZ hashes like the original ISO. WIA/RVZ images of GameCube
  discs have a single raw-data region starting at 0x80 (the first 0x80 bytes live in the header), grouped in
  32 KiB-aligned chunks.
* Test containers built by `tests/make_container_images.py` (all methods, chunk sizes 32 KiB-2 MiB) decode to the
  same SHA-1 as the source image; speed here: zstd ~250 MB/s, bzip2 ~35 MB/s, LZMA ~15-40 MB/s.
* CISO has no image-size field (Dolphin reports the full block-map range), so the reader uses the standard
  1,459,978,240-byte disc size when the map covers it.

## Points, lines and fog
* The game draws particle sprites (e.g. the sparkle ring around weapon pickups) as GX_POINTS with SU_LPSIZE point
  sizes; these were silently dropped before. They are expanded to screen-aligned quads (size in 1/6 pixel, texcoord
  offsets from SU_SSIZE bit 19/18 via the {0,1/16,1/8,1/4,1/2,1,1,1} table), with culling off, in both renderers.
* Fog follows the hardware formula: perspective ze = a*2^24/(bmag - (z>>bshift)), ortho ze = a*z/2^24, f = clamp(ze-c),
  then the fsel curve (lin/exp/exp2/bexp/bexp2); colour blended by round(f*256)>>8. The first level never enables it.
  Range adjustment (BP 0xE8-0xED) is not emulated yet (a warning is logged if the game turns it on).

## Memory card
* Without a card: "No Memory Card found". With an **erased** card image the game says "The Memory Card in Slot A is
  damaged" and offers no format option: `CARDMount` rejects a card whose header serial doesn't match the console
  SRAM's flash ID (`__CARDVerify`), so new cards are formatted by the runtime exactly like `CARDFormat` does, and the
  SRAM flash ID is derived from whatever card is inserted (as Dolphin does), so cards formatted elsewhere mount too.
* The game creates a 3-block save file `SeriousSam` (G3BE9G) automatically during the new-game flow and reads it
  back (blocks 5-7) on the next boot.
* Audio crackle root causes: (1) with a coarse host timer (Windows ~15.6 ms sleeps) the AI DMA engine caught up by
  several buffers at once and replayed a buffer the game hadn't replaced (40% of output); (2) the game thread
  answers the AI interrupt late while it flushes a frame to the rasterizer, same effect. Fixed by stopping at each
  buffer end until the game's `AIInitDMA` handoff (up to 100 ms), plus 1 ms timer resolution on Windows.

## Earlier state: the game loop runs
With the interrupt controller, native threads/alarms, ARAM, DI, VI, AI, DSP mailbox and GX command processor, the
recompiled game boots all the way into its engine loop. In 10 s headless (USA Rev 1):
* ~300 frames (EFB copies), ~46k primitives / 186k vertices, 6.5 MB of GX commands (stream stays in sync)
* 300 disc reads (9 MB): `Global.ssg`, `Data.ssg`, `BackGround.sst`, loading screens... all through the SDK DVD driver
* 275 ARAM DMAs, ~2,200 interrupts, AX audio microcode "booted" (DSP_INIT handshake)
Game log excerpt:
```
------ >> IMPORT_Read_Old(/Data.ssg)
IMPORT: Detected new style export header "CLIMAX-". (64)
------ << IMPORT_Read_Old(/Data.ssg) success
------ >> IMPORT_Read_Old(textures/BackGround.sst)   ... success
```
The game's own GPU hang detector (`SYSTEM-HANG … SyncToken … GP status`) was what pointed at the missing command processor.

More bugs found on the real binary:
* Function-pointer discovery lost `lis` bases kept in callee-saved registers across calls (missed ARQ callback 80156E20).
* 64-bit stores (`stfd`) to the GX FIFO bypassed MMIO.
* Missing game files (my first test set had only `sys/`) made a recursive hierarchy walk (800F601C) overflow into SDK data.

## Boot progress history (headless runner)
1. `__start` → `OSInit` (801B42C0): interrupt masking, BAT/MMU setup through real-mode `rfi` (Config24MB), EXI init. ✅
2. `__OSInitAudioSystem` (801B51C8): DSP handshake, replaced by a native no-op hook. ✅
3. Game `main()` at **8010A664** → 80161CC8 → 8010E374 → **`ARInit` (801C31B4) → `__ARChecksize` (801C32F8)**: polls the
   DSP/ARAM DMA registers (CC005020/22, CC00500A). ⛔ **Current stop point.** Next step: ARAM + AR DMA HLE (16 MB ARAM buffer).

Bugs found and fixed on the real binary:
* `rlwinm` with MB > ME (wrap-around mask) was inverted, which made `__OSMaskInterrupts` loop forever.
* Switch-case blocks were being picked up as "functions" through their jump-table entries. Jump tables are now detected first.
* Real-mode (physical) branch targets (0x001B7108) are now mapped to their cached virtual address.
