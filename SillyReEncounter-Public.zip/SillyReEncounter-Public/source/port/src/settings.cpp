#include "settings.h"

#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <map>
#include <sstream>
#include <type_traits>

namespace port {

namespace {

struct ActionInfo { const char* id; const char* name; };
const ActionInfo kActions[ACT_COUNT] = {
    {"move_up", "Move forward"},        {"move_down", "Move back"},
    {"move_left", "Strafe left"},       {"move_right", "Strafe right"},
    {"look_up", "Look up"},             {"look_down", "Look down"},
    {"look_left", "Turn left"},         {"look_right", "Turn right"},
    {"a", "A  (jump / select)"},        {"b", "B  (back)"},
    {"x", "X"},                         {"y", "Y"},
    {"z", "Z"},                         {"start", "Start  (pause)"},
    {"l", "L trigger"},                 {"r", "R trigger  (fire)"},
    {"dpad_up", "D-pad up"},            {"dpad_down", "D-pad down"},
    {"dpad_left", "D-pad left"},        {"dpad_right", "D-pad right"},
};

std::string trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}

const char* mouse_name(int b) {
    switch (b) {
    case SDL_BUTTON_LEFT: return "Mouse Left";
    case SDL_BUTTON_RIGHT: return "Mouse Right";
    case SDL_BUTTON_MIDDLE: return "Mouse Middle";
    case SDL_BUTTON_X1: return "Mouse Back";
    case SDL_BUTTON_X2: return "Mouse Forward";
    }
    return "Mouse ?";
}

const char* pad_button_name(int b) {
    switch (b) {
    case SDL_CONTROLLER_BUTTON_A: return "Pad A / Cross";
    case SDL_CONTROLLER_BUTTON_B: return "Pad B / Circle";
    case SDL_CONTROLLER_BUTTON_X: return "Pad X / Square";
    case SDL_CONTROLLER_BUTTON_Y: return "Pad Y / Triangle";
    case SDL_CONTROLLER_BUTTON_BACK: return "Pad Back / Select";
    case SDL_CONTROLLER_BUTTON_GUIDE: return "Pad Guide";
    case SDL_CONTROLLER_BUTTON_START: return "Pad Start";
    case SDL_CONTROLLER_BUTTON_LEFTSTICK: return "Pad Left Stick Click";
    case SDL_CONTROLLER_BUTTON_RIGHTSTICK: return "Pad Right Stick Click";
    case SDL_CONTROLLER_BUTTON_LEFTSHOULDER: return "Pad Left Bumper";
    case SDL_CONTROLLER_BUTTON_RIGHTSHOULDER: return "Pad Right Bumper";
    case SDL_CONTROLLER_BUTTON_DPAD_UP: return "Pad D-pad Up";
    case SDL_CONTROLLER_BUTTON_DPAD_DOWN: return "Pad D-pad Down";
    case SDL_CONTROLLER_BUTTON_DPAD_LEFT: return "Pad D-pad Left";
    case SDL_CONTROLLER_BUTTON_DPAD_RIGHT: return "Pad D-pad Right";
    }
    return "Pad Button ?";
}

const char* pad_axis_name(int a) {
    switch (a) {
    case SDL_CONTROLLER_AXIS_TRIGGERLEFT: return "Pad Left Trigger";
    case SDL_CONTROLLER_AXIS_TRIGGERRIGHT: return "Pad Right Trigger";
    }
    return "Pad Axis ?";
}

} // namespace

const char* action_name(int a) { return a >= 0 && a < ACT_COUNT ? kActions[a].name : "?"; }
const char* action_id(int a) { return a >= 0 && a < ACT_COUNT ? kActions[a].id : "?"; }

Settings::Settings() {
    reset_graphics();
    reset_audio();
    reset_keyboard();
    reset_gamepad();
    pause_in_menu = true;
}

void Settings::reset_graphics() {
    renderer = "gpu"; scale = 3; aspect = 1; fps_limit = 60; fov = 63; vsync = true; fullscreen = false; show_top_bar = true;
}

void Settings::reset_audio() { volume = 100; muted = false; audio_hq = true; }

void Settings::reset_keyboard() {
    for (auto& b : kb) b[0] = b[1] = Bind{};
    auto k = [](SDL_Scancode s) { return Bind::key(s); };
    kb[ACT_MOVE_UP][0] = k(SDL_SCANCODE_W);        kb[ACT_MOVE_UP][1] = k(SDL_SCANCODE_UP);
    kb[ACT_MOVE_DOWN][0] = k(SDL_SCANCODE_S);      kb[ACT_MOVE_DOWN][1] = k(SDL_SCANCODE_DOWN);
    kb[ACT_MOVE_LEFT][0] = k(SDL_SCANCODE_A);      kb[ACT_MOVE_LEFT][1] = k(SDL_SCANCODE_LEFT);
    kb[ACT_MOVE_RIGHT][0] = k(SDL_SCANCODE_D);     kb[ACT_MOVE_RIGHT][1] = k(SDL_SCANCODE_RIGHT);
    kb[ACT_LOOK_UP][0] = k(SDL_SCANCODE_I);
    kb[ACT_LOOK_DOWN][0] = k(SDL_SCANCODE_K);
    kb[ACT_LOOK_LEFT][0] = k(SDL_SCANCODE_J);
    kb[ACT_LOOK_RIGHT][0] = k(SDL_SCANCODE_L);
    kb[ACT_A][0] = k(SDL_SCANCODE_SPACE);
    kb[ACT_B][0] = k(SDL_SCANCODE_BACKSPACE);      kb[ACT_B][1] = k(SDL_SCANCODE_ESCAPE);
    kb[ACT_X][0] = k(SDL_SCANCODE_E);
    kb[ACT_Y][0] = k(SDL_SCANCODE_Q);
    kb[ACT_Z][0] = k(SDL_SCANCODE_TAB);
    kb[ACT_START][0] = k(SDL_SCANCODE_RETURN);
    kb[ACT_L][0] = Bind::mouse(SDL_BUTTON_RIGHT);  kb[ACT_L][1] = k(SDL_SCANCODE_LSHIFT);
    kb[ACT_R][0] = Bind::mouse(SDL_BUTTON_LEFT);   kb[ACT_R][1] = k(SDL_SCANCODE_LCTRL);
    kb[ACT_DPAD_UP][0] = k(SDL_SCANCODE_KP_8);
    kb[ACT_DPAD_DOWN][0] = k(SDL_SCANCODE_KP_2);
    kb[ACT_DPAD_LEFT][0] = k(SDL_SCANCODE_KP_4);
    kb[ACT_DPAD_RIGHT][0] = k(SDL_SCANCODE_KP_6);
    mouse_look = true; mouse_aim = true; mouse_sens = 1.0f; mouse_invert_y = false;
}

void Settings::reset_gamepad() {
    for (auto& b : pad) b = Bind{};
    pad[ACT_A] = Bind::button(SDL_CONTROLLER_BUTTON_A);
    pad[ACT_B] = Bind::button(SDL_CONTROLLER_BUTTON_B);
    pad[ACT_X] = Bind::button(SDL_CONTROLLER_BUTTON_X);
    pad[ACT_Y] = Bind::button(SDL_CONTROLLER_BUTTON_Y);
    pad[ACT_Z] = Bind::button(SDL_CONTROLLER_BUTTON_RIGHTSHOULDER);
    pad[ACT_START] = Bind::button(SDL_CONTROLLER_BUTTON_START);
    pad[ACT_L] = Bind::axis(SDL_CONTROLLER_AXIS_TRIGGERLEFT);
    pad[ACT_R] = Bind::axis(SDL_CONTROLLER_AXIS_TRIGGERRIGHT);
    pad[ACT_DPAD_UP] = Bind::button(SDL_CONTROLLER_BUTTON_DPAD_UP);
    pad[ACT_DPAD_DOWN] = Bind::button(SDL_CONTROLLER_BUTTON_DPAD_DOWN);
    pad[ACT_DPAD_LEFT] = Bind::button(SDL_CONTROLLER_BUTTON_DPAD_LEFT);
    pad[ACT_DPAD_RIGHT] = Bind::button(SDL_CONTROLLER_BUTTON_DPAD_RIGHT);
    pad_deadzone = 0.15f; trigger_threshold = 0.8f; look_sens = 1.0f; pad_invert_y = false; swap_sticks = false;
}

std::string bind_name(const Bind& b) {
    switch (b.type) {
    case Bind::KEY: {
        const char* n = SDL_GetScancodeName(SDL_Scancode(b.code));
        return n && *n ? n : "Key " + std::to_string(b.code);
    }
    case Bind::MOUSE: return mouse_name(b.code);
    case Bind::PAD_BUTTON: return pad_button_name(b.code);
    case Bind::PAD_AXIS: return pad_axis_name(b.code);
    default: return "-";
    }
}

std::string bind_to_string(const Bind& b) {
    switch (b.type) {
    case Bind::KEY: {
        const char* n = SDL_GetScancodeName(SDL_Scancode(b.code));
        return n && *n ? std::string("key:") + n : "scancode:" + std::to_string(b.code);
    }
    case Bind::MOUSE: return "mouse:" + std::to_string(b.code);
    case Bind::PAD_BUTTON: {
        const char* n = SDL_GameControllerGetStringForButton(SDL_GameControllerButton(b.code));
        return std::string("button:") + (n ? n : "?");
    }
    case Bind::PAD_AXIS: {
        const char* n = SDL_GameControllerGetStringForAxis(SDL_GameControllerAxis(b.code));
        return std::string("axis:") + (n ? n : "?");
    }
    default: return "none";
    }
}

Bind bind_from_string(const std::string& s0) {
    std::string s = trim(s0);
    size_t c = s.find(':');
    if (c == std::string::npos) return {};
    std::string t = s.substr(0, c), v = s.substr(c + 1);
    if (t == "key") {
        SDL_Scancode sc = SDL_GetScancodeFromName(v.c_str());
        return sc == SDL_SCANCODE_UNKNOWN ? Bind{} : Bind::key(sc);
    }
    if (t == "scancode") return Bind::key(SDL_Scancode(atoi(v.c_str())));
    if (t == "mouse") { int b = atoi(v.c_str()); return b >= 1 && b <= 5 ? Bind::mouse(b) : Bind{}; }
    if (t == "button") {
        auto b = SDL_GameControllerGetButtonFromString(v.c_str());
        return b == SDL_CONTROLLER_BUTTON_INVALID ? Bind{} : Bind::button(b);
    }
    if (t == "axis") {
        auto a = SDL_GameControllerGetAxisFromString(v.c_str());
        return a == SDL_CONTROLLER_AXIS_INVALID ? Bind{} : Bind::axis(a);
    }
    return {};
}

bool load_settings(Settings& s, const std::string& path) {
    std::ifstream in(std::filesystem::u8path(path));
    if (!in) return false;
    std::map<std::string, std::string> kv;
    std::string line;
    while (std::getline(in, line)) {
        line = trim(line);
        if (line.empty() || line[0] == '#' || line[0] == ';' || line[0] == '[') continue;
        size_t eq = line.find('=');
        if (eq == std::string::npos) continue;
        std::string val = line.substr(eq + 1);
        size_t hash = val.find(" #");  // trailing comment
        if (hash != std::string::npos) val = val.substr(0, hash);
        kv[trim(line.substr(0, eq))] = trim(val);
    }
    auto get = [&](const char* k, auto& v) {
        auto it = kv.find(k);
        if (it == kv.end()) return;
        using T = std::decay_t<decltype(v)>;
        if constexpr (std::is_same_v<T, bool>) v = it->second == "1" || it->second == "true" || it->second == "on";
        else if constexpr (std::is_same_v<T, int>) v = atoi(it->second.c_str());
        else if constexpr (std::is_same_v<T, float>) v = float(atof(it->second.c_str()));
        else v = it->second;
    };
    get("renderer", s.renderer);
    get("scale", s.scale);
    get("aspect", s.aspect);
    get("fps_limit", s.fps_limit);
    get("fov", s.fov);
    get("vsync", s.vsync);
    get("show_top_bar", s.show_top_bar);
    get("fullscreen", s.fullscreen);
    get("volume", s.volume);
    get("muted", s.muted);
    get("audio_hq", s.audio_hq);
    get("mouse_look", s.mouse_look);
    get("mouse_aim", s.mouse_aim);
    get("mouse_sensitivity", s.mouse_sens);
    get("mouse_invert_y", s.mouse_invert_y);
    get("pad_deadzone", s.pad_deadzone);
    get("pad_trigger_threshold", s.trigger_threshold);
    get("pad_look_sensitivity", s.look_sens);
    get("pad_invert_y", s.pad_invert_y);
    get("pad_swap_sticks", s.swap_sticks);
    get("pause_in_menu", s.pause_in_menu);
    for (int a = 0; a < ACT_COUNT; a++) {
        auto it = kv.find(std::string("kb.") + action_id(a));
        if (it != kv.end()) {
            std::string v = it->second;
            size_t comma = v.find(',');
            s.kb[a][0] = bind_from_string(v.substr(0, comma));
            s.kb[a][1] = comma == std::string::npos ? Bind{} : bind_from_string(v.substr(comma + 1));
        }
        if (a >= kFirstButtonAction) {
            auto p = kv.find(std::string("pad.") + action_id(a));
            if (p != kv.end()) s.pad[a] = bind_from_string(p->second);
        }
    }
    // Sanitize.
    if (s.renderer != "software") s.renderer = "gpu";
    s.scale = std::clamp(s.scale, 1, 8);
    s.aspect = std::clamp(s.aspect, 0, 2);
    s.fov = std::clamp(s.fov, 45, 110);
    if (s.fps_limit != 0) s.fps_limit = std::clamp(s.fps_limit, 30, 1000);
    s.volume = std::clamp(s.volume, 0, 200);
    s.mouse_sens = std::clamp(s.mouse_sens, 0.1f, 10.f);
    s.pad_deadzone = std::clamp(s.pad_deadzone, 0.f, 0.6f);
    s.trigger_threshold = std::clamp(s.trigger_threshold, 0.1f, 1.f);
    s.look_sens = std::clamp(s.look_sens, 0.1f, 4.f);
    return true;
}

bool save_settings(const Settings& s, const std::string& path) {
    std::ostringstream o;
    o << "# Silly ReEncounter settings (edited in-game with F12)\n";
    o << "[graphics]\n";
    o << "renderer = " << s.renderer << "\n";
    o << "scale = " << s.scale << "\n";
    o << "aspect = " << s.aspect << "    # 0 = 4:3, 1 = 16:9, 2 = 21:9\n";
    o << "fps_limit = " << s.fps_limit << "    # 60 = original, 0 = unlimited (vsync)\n";
    o << "fov = " << s.fov << "    # gameplay vertical field of view in degrees, 63 = original\n";
    o << "vsync = " << (s.vsync ? 1 : 0) << "\n";
    o << "show_top_bar = " << (s.show_top_bar ? 1 : 0) << "    # fps / info bar at the top (Shift+F1)\n";
    o << "fullscreen = " << (s.fullscreen ? 1 : 0) << "\n";
    o << "[audio]\n";
    o << "volume = " << s.volume << "\n";
    o << "muted = " << (s.muted ? 1 : 0) << "\n";
    o << "audio_hq = " << (s.audio_hq ? 1 : 0) << "  # 1 high-quality resampling, 0 original (linear, as on the GameCube)\n";
    o << "[keyboard_mouse]\n";
    o << "mouse_look = " << (s.mouse_look ? 1 : 0) << "\n";
    o << "mouse_aim = " << (s.mouse_aim ? 1 : 0) << "    # 1 = direct aim, 0 = mouse emulates the C-stick\n";
    o << "mouse_sensitivity = " << s.mouse_sens << "\n";
    o << "mouse_invert_y = " << (s.mouse_invert_y ? 1 : 0) << "\n";
    for (int a = 0; a < ACT_COUNT; a++)
        o << "kb." << action_id(a) << " = " << bind_to_string(s.kb[a][0]) << ", " << bind_to_string(s.kb[a][1]) << "\n";
    o << "[gamepad]\n";
    o << "pad_deadzone = " << s.pad_deadzone << "\n";
    o << "pad_trigger_threshold = " << s.trigger_threshold << "\n";
    o << "pad_look_sensitivity = " << s.look_sens << "\n";
    o << "pad_invert_y = " << (s.pad_invert_y ? 1 : 0) << "\n";
    o << "pad_swap_sticks = " << (s.swap_sticks ? 1 : 0) << "\n";
    for (int a = kFirstButtonAction; a < ACT_COUNT; a++) o << "pad." << action_id(a) << " = " << bind_to_string(s.pad[a]) << "\n";
    o << "[menu]\n";
    o << "pause_in_menu = " << (s.pause_in_menu ? 1 : 0) << "\n";
    namespace fs = std::filesystem;
    fs::path dst = fs::u8path(path), tmp = fs::u8path(path + ".tmp");
    {
        std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
        if (!f) return false;
        f << o.str();
        if (!f) return false;
    }
    std::error_code ec;
    fs::rename(tmp, dst, ec);  // replaces an existing file
    return !ec;
}

} // namespace port
