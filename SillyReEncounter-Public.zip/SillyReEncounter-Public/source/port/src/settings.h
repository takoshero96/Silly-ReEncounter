// Port settings: graphics, audio and controls. Stored in settings.ini next to the game exe; edited in the F12
// settings menu (settings_menu.cpp). Command-line options override the file for that run.
#pragma once
#include <SDL.h>

#include <cstdint>
#include <string>

namespace port {

// A physical input bound to a GameCube control.
struct Bind {
    enum Type : uint8_t { NONE, KEY, MOUSE, PAD_BUTTON, PAD_AXIS };
    Type type = NONE;
    int16_t code = 0;  // SDL_Scancode / mouse button (SDL_BUTTON_*) / SDL_GameControllerButton / SDL_GameControllerAxis
    bool operator==(const Bind& o) const { return type == o.type && code == o.code; }
    static Bind key(SDL_Scancode s) { return {KEY, int16_t(s)}; }
    static Bind mouse(int b) { return {MOUSE, int16_t(b)}; }
    static Bind button(SDL_GameControllerButton b) { return {PAD_BUTTON, int16_t(b)}; }
    static Bind axis(SDL_GameControllerAxis a) { return {PAD_AXIS, int16_t(a)}; }
};

// GameCube controls. Stick/C-stick directions are digital on the keyboard (full tilt).
enum Action : int {
    ACT_MOVE_UP, ACT_MOVE_DOWN, ACT_MOVE_LEFT, ACT_MOVE_RIGHT,
    ACT_LOOK_UP, ACT_LOOK_DOWN, ACT_LOOK_LEFT, ACT_LOOK_RIGHT,
    ACT_A, ACT_B, ACT_X, ACT_Y, ACT_Z, ACT_START, ACT_L, ACT_R,
    ACT_DPAD_UP, ACT_DPAD_DOWN, ACT_DPAD_LEFT, ACT_DPAD_RIGHT,
    ACT_COUNT
};
constexpr int kFirstButtonAction = ACT_A;  // gamepad bindings exist for ACT_A..ACT_DPAD_RIGHT

const char* action_name(int a);   // "Move forward", "A (jump / select)", ...
const char* action_id(int a);     // ini key suffix: "move_up", "a", ...

struct Settings {
    // Graphics
    std::string renderer = "gpu";  // "gpu" or "software" (applies on restart)
    int scale = 3;                 // GPU internal resolution 1..8
    int aspect = 1;                // 0 4:3, 1 16:9, 2 21:9
    int fps_limit = 60;            // 60 original, 120, 144, 0 unlimited
    int fov = 63;                  // gameplay vertical field of view in degrees (63 = original)
    bool vsync = true;
    bool fullscreen = false;
    bool show_top_bar = true;      // info bar at the top: fps, frame limit, key hints (Shift+F1)
    // Audio
    int volume = 100;              // 0..200 %
    bool muted = false;
    bool audio_hq = true;          // band-limited resampling (off: the DSP's original linear interpolation)
    // Keyboard / mouse
    Bind kb[ACT_COUNT][2];
    bool mouse_look = true;        // captured mouse turns the view
    bool mouse_aim = true;         // direct 1:1 aim in gameplay (off: the mouse emulates the C-stick)
    float mouse_sens = 1.0f;
    bool mouse_invert_y = false;
    // Gamepad
    Bind pad[ACT_COUNT];           // digital/trigger controls (sticks are fixed: left = move, right = look)
    float pad_deadzone = 0.15f;
    float trigger_threshold = 0.8f;  // analog trigger travel that also clicks L/R
    float look_sens = 1.0f;
    bool pad_invert_y = false;
    bool swap_sticks = false;
    // Menu
    bool pause_in_menu = true;

    Settings();
    void reset_graphics();
    void reset_audio();
    void reset_keyboard();
    void reset_gamepad();
};

// Load/save settings.ini (missing file or keys keep defaults). Return false on I/O error.
bool load_settings(Settings& s, const std::string& path);
bool save_settings(const Settings& s, const std::string& path);

std::string bind_name(const Bind& b);   // "Space", "Mouse Left", "Pad A", "Pad Right Trigger", "-" for none
std::string bind_to_string(const Bind& b);  // ini form: "key:Space", "mouse:1", "button:a", "axis:righttrigger"
Bind bind_from_string(const std::string& s);

} // namespace port
