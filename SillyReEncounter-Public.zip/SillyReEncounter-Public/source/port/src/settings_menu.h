// In-game settings menu (F12, or Back/Select on a gamepad). Dear ImGui window with Graphics, Audio,
// Keyboard & Mouse and Gamepad tabs, including input rebinding.
#pragma once
#include <SDL.h>

#include <string>

#include "settings.h"

namespace port {

struct MenuInfo {
    bool gpu_active = false;        // GPU renderer running (resolution slider available)
    std::string renderer_info;      // e.g. "NVIDIA GeForce RTX 4060 ..."
    int out_w = 0, out_h = 0;       // current GPU output size
    std::string pad_name;           // connected controller, empty if none
    std::string settings_path;
};

bool menu_open();
void menu_set_open(bool open);
void menu_select_tab(int tab);    // 0 graphics, 1 audio, 2 keyboard & mouse, 3 gamepad, 4 hotkeys
bool menu_capturing();              // waiting for a key/button to bind

// Feed SDL events first; returns true if the event was consumed by a pending rebind.
// Sets `changed` when a binding was assigned.
bool menu_handle_event(const SDL_Event& e, Settings& s, bool& changed);

// Draws the menu when open. Returns true if any setting changed this frame.
bool draw_menu(Settings& s, const MenuInfo& info);

} // namespace port
