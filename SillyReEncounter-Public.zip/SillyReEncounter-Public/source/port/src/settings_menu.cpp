#include "settings_menu.h"

#include <imgui.h>

#include <algorithm>
#include <cmath>
#include <cstdio>

namespace port {

namespace {

bool g_open = false;
int g_select_tab = -1;  // tab to select on the next frame
struct Capture { bool active = false; bool pad = false; int action = 0; int slot = 0; } g_cap;

const ImVec4 kDim(0.62f, 0.62f, 0.66f, 1), kAccent(1.0f, 0.76f, 0.22f, 1), kWarn(1.0f, 0.55f, 0.35f, 1);

void assign(Settings& s, const Bind& b) {
    if (!g_cap.pad) {
        // One key per control: drop the key from any other control it was bound to.
        for (int a = 0; a < ACT_COUNT; a++)
            for (int k = 0; k < 2; k++)
                if (s.kb[a][k] == b && !(a == g_cap.action && k == g_cap.slot)) s.kb[a][k] = Bind{};
        s.kb[g_cap.action][g_cap.slot] = b;
    } else {
        for (int a = kFirstButtonAction; a < ACT_COUNT; a++)
            if (s.pad[a] == b && a != g_cap.action) s.pad[a] = Bind{};
        s.pad[g_cap.action] = b;
    }
    g_cap.active = false;
}

void help(const char* text) {
    ImGui::SameLine();
    ImGui::TextDisabled("(?)");
    if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s", text);
}

bool slider_pct(const char* label, float& v, float lo, float hi) {
    int pct = int(v * 100.f + 0.5f);
    bool ch = ImGui::SliderInt(label, &pct, int(lo * 100), int(hi * 100), "%d%%");
    if (ch) v = float(pct) / 100.f;
    return ch;
}

bool bind_button(const Bind& b, bool pad, int action, int slot) {
    bool waiting = g_cap.active && g_cap.pad == pad && g_cap.action == action && g_cap.slot == slot;
    std::string label = waiting ? std::string(pad ? "press a pad button..." : "press a key or mouse button...") : bind_name(b);
    label += "##" + std::to_string(pad) + "_" + std::to_string(action) + "_" + std::to_string(slot);
    if (waiting) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.55f, 0.35f, 0.05f, 1));
    bool clicked = ImGui::Button(label.c_str(), ImVec2(-1, 0));
    if (waiting) ImGui::PopStyleColor();
    if (clicked) g_cap = {true, pad, action, slot};
    // Right click clears the binding.
    return ImGui::IsItemHovered() && ImGui::IsMouseClicked(ImGuiMouseButton_Right);
}

bool tab_graphics(Settings& s, const MenuInfo& info) {
    bool ch = false;
    ImGui::SeparatorText("Display");
    ch |= ImGui::Checkbox("Fullscreen  (F11 / Alt+Enter)", &s.fullscreen);
    ch |= ImGui::Checkbox("Vertical sync", &s.vsync);
    help("Syncs to your monitor's refresh rate: no tearing. Turn it off only with a frame rate limit set.");
    ch |= ImGui::Checkbox("Show info bar at the top  (Shift+F1)", &s.show_top_bar);
    help("The small bar in the top-left corner with the frame rate, frame rate limit and key hints.");

    ImGui::SeparatorText("Frame rate");
    static const int kFps[] = {60, 120, 144, 165, 240, 0};
    static const char* kFpsNames[] = {"60 (original)", "120", "144", "165", "240", "Unlimited (vsync)"};
    int cur = 0;
    for (int i = 0; i < 6; i++) if (kFps[i] == s.fps_limit) cur = i;
    ImGui::SetNextItemWidth(260);
    if (ImGui::Combo("Frame rate limit  (F10)", &cur, kFpsNames, 6)) { s.fps_limit = kFps[cur]; ch = true; }
    help("The game times everything by real elapsed time, so it plays at the same speed at any frame rate.\n"
         "Unlimited is still capped by your monitor when vertical sync is on.");

    ImGui::SeparatorText("Image");
    static const char* kAspect[] = {"4:3 (original)", "16:9", "21:9"};
    ImGui::SetNextItemWidth(260);
    ch |= ImGui::Combo("Aspect ratio  (F8)", &s.aspect, kAspect, 3);
    help("Widescreen widens the view during gameplay; menus and cutscenes stay 4:3.");
    {
        static const float kWide[3] = {1.0f, 4.0f / 3.0f, 7.0f / 4.0f};
        float hfov = 2.f * std::atan(std::tan(0.5f * float(s.fov) * 0.017453292f) * 1.4286f * kWide[std::clamp(s.aspect, 0, 2)]) / 0.017453292f;
        char ffmt[64];
        snprintf(ffmt, sizeof(ffmt), s.fov == 63 ? "%%d deg (original)  - %.0f horizontal" : "%%d deg  - %.0f horizontal", hfov);
        ImGui::SetNextItemWidth(260);
        ch |= ImGui::SliderInt("Field of view", &s.fov, 45, 110, ffmt);
        help("Vertical field of view in gameplay (the game uses 63). The horizontal value depends on the aspect ratio.\n"
             "Your weapon, menus and cutscene framing are not affected. Right-click to reset.");
        if (ImGui::IsItemHovered() && ImGui::IsMouseClicked(ImGuiMouseButton_Right)) { s.fov = 63; ch = true; }
    }
    ImGui::BeginDisabled(!info.gpu_active);
    ImGui::SetNextItemWidth(260);
    char fmt[64];
    snprintf(fmt, sizeof(fmt), "%%dx  (%dx%d)", 640 * s.scale, 448 * s.scale);
    ch |= ImGui::SliderInt("Internal resolution  (F6/F7)", &s.scale, 1, 8, fmt);
    ImGui::EndDisabled();
    help("Renders the game at a multiple of the GameCube's 640x448. Higher is sharper but costs GPU time.");

    ImGui::SeparatorText("Renderer");
    int r = s.renderer == "software" ? 1 : 0;
    static const char* kRend[] = {"GPU (OpenGL 3.3)", "Software (CPU)"};
    ImGui::SetNextItemWidth(260);
    if (ImGui::Combo("Renderer", &r, kRend, 2)) { s.renderer = r ? "software" : "gpu"; ch = true; }
    bool running_sw = !info.gpu_active;
    if ((s.renderer == "software") != running_sw) ImGui::TextColored(kWarn, "Takes effect the next time you start the game.");
    if (info.gpu_active) ImGui::TextColored(kDim, "Running: %s", info.renderer_info.c_str());
    else ImGui::TextColored(kDim, "Running: software renderer");
    ImGui::Spacing();
    if (ImGui::Button("Reset graphics to defaults")) { s.reset_graphics(); ch = true; }
    return ch;
}

void tab_hotkeys() {
    ImGui::TextColored(kDim, "Keys that work any time in the game window (not rebindable).");
    ImGui::Spacing();
    static const char* keys[][2] = {
        {"F12  /  pad Back", "Settings menu (Esc closes it)"},
        {"F1", "Log and statistics window"},
        {"Shift+F1", "Show / hide the info bar at the top (fps, limit, key hints)"},
        {"F2", "Release the mouse (click the game to capture it again)"},
        {"F3", "Mute / unmute"},
        {"F4  /  F5", "Volume down / up (10% steps)"},
        {"F6  /  F7", "Internal resolution down / up (GPU renderer)"},
        {"F8", "Aspect ratio: 16:9 / 21:9 / 4:3"},
        {"F9", "Capture the next frame to the debug folder (GPU renderer, for bug reports)"},
        {"F10", "Frame rate limit: 60 / 120 / 144 / unlimited"},
        {"F11  /  Alt+Enter", "Fullscreen"},
    };
    if (ImGui::BeginTable("##keys", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerV)) {
        ImGui::TableSetupColumn("Key", ImGuiTableColumnFlags_WidthFixed, 170);
        ImGui::TableSetupColumn("Action");
        for (auto& k : keys) {
            ImGui::TableNextRow();
            ImGui::TableNextColumn();
            ImGui::TextColored(kAccent, "%s", k[0]);
            ImGui::TableNextColumn();
            ImGui::TextUnformatted(k[1]);
        }
        ImGui::EndTable();
    }
}

bool tab_audio(Settings& s) {
    bool ch = false;
    ImGui::SetNextItemWidth(300);
    ch |= ImGui::SliderInt("Volume  (F4/F5)", &s.volume, 0, 200, "%d%%");
    ch |= ImGui::Checkbox("Mute  (F3)", &s.muted);
    ImGui::SeparatorText("Quality");
    int q = s.audio_hq ? 1 : 0;
    ImGui::SetNextItemWidth(300);
    if (ImGui::Combo("Resampling", &q, "Original (linear, as on GameCube)\0High quality (band-limited)\0")) {
        s.audio_hq = q == 1;
        ch = true;
    }
    ImGui::TextColored(kDim, "The music is 44.1 kHz and the GameCube converts it to 32 kHz with linear interpolation,\n"
                             "which dulls the treble and adds aliasing. High quality uses a 64-tap filter instead.");
    ImGui::Spacing();
    if (ImGui::Button("Reset audio to defaults")) { s.reset_audio(); ch = true; }
    return ch;
}

bool tab_keyboard(Settings& s) {
    bool ch = false;
    ImGui::TextColored(kDim, "Click a slot, then press a key or mouse button. Right-click a slot to clear it. Esc cancels.");
    ImGui::SeparatorText("Mouse");
    ch |= ImGui::Checkbox("Mouse look  (click the game to capture the mouse, F2 releases it)", &s.mouse_look);
    ImGui::BeginDisabled(!s.mouse_look);
    ch |= ImGui::Checkbox("Direct mouse aim", &s.mouse_aim);
    help("On: the mouse turns the view directly, 1:1 like a PC shooter (no acceleration, same at any frame rate).\n"
         "Off: the mouse moves the GameCube C-stick, like the original controls.");
    ImGui::EndDisabled();
    ImGui::SetNextItemWidth(300);
    ch |= slider_pct("Mouse sensitivity", s.mouse_sens, 0.1f, 5.0f);
    ch |= ImGui::Checkbox("Invert mouse Y", &s.mouse_invert_y);
    ImGui::SeparatorText("Bindings");
    if (ImGui::BeginTable("##kb", 3, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerV | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("GameCube control", ImGuiTableColumnFlags_WidthStretch, 1.2f);
        ImGui::TableSetupColumn("Primary", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableSetupColumn("Secondary", ImGuiTableColumnFlags_WidthStretch, 1.0f);
        ImGui::TableHeadersRow();
        for (int a = 0; a < ACT_COUNT; a++) {
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted(action_name(a));
            for (int k = 0; k < 2; k++) {
                ImGui::TableSetColumnIndex(1 + k);
                if (bind_button(s.kb[a][k], false, a, k)) { s.kb[a][k] = Bind{}; ch = true; }
            }
        }
        ImGui::EndTable();
    }
    ImGui::Spacing();
    if (ImGui::Button("Reset keyboard & mouse to defaults")) { s.reset_keyboard(); ch = true; }
    return ch;
}

bool tab_gamepad(Settings& s, const MenuInfo& info) {
    bool ch = false;
    if (info.pad_name.empty()) ImGui::TextColored(kWarn, "No controller connected (plug one in at any time).");
    else ImGui::TextColored(kDim, "Controller: %s", info.pad_name.c_str());
    ImGui::TextColored(kDim, "Left stick = move, right stick = look. Back/Select opens this menu.");
    ImGui::SeparatorText("Sticks and triggers");
    ImGui::SetNextItemWidth(300);
    ch |= slider_pct("Stick deadzone", s.pad_deadzone, 0.0f, 0.5f);
    help("Stick movement smaller than this is ignored (fixes drift). The rest of the range is rescaled.");
    ImGui::SetNextItemWidth(300);
    ch |= slider_pct("Look sensitivity", s.look_sens, 0.25f, 3.0f);
    ImGui::SetNextItemWidth(300);
    ch |= slider_pct("Trigger click point", s.trigger_threshold, 0.1f, 1.0f);
    help("How far an analog trigger must be pulled to also press the GameCube's digital L/R click.");
    ch |= ImGui::Checkbox("Invert look Y", &s.pad_invert_y);
    ch |= ImGui::Checkbox("Swap sticks (left = look, right = move)", &s.swap_sticks);
    ImGui::SeparatorText("Buttons");
    ImGui::TextColored(kDim, "Click a slot, then press a controller button or pull a trigger. Right-click clears. Esc cancels.");
    if (ImGui::BeginTable("##pad", 2, ImGuiTableFlags_RowBg | ImGuiTableFlags_BordersInnerV | ImGuiTableFlags_SizingStretchProp)) {
        ImGui::TableSetupColumn("GameCube control", ImGuiTableColumnFlags_WidthStretch, 1.2f);
        ImGui::TableSetupColumn("Controller", ImGuiTableColumnFlags_WidthStretch, 1.4f);
        ImGui::TableHeadersRow();
        for (int a = kFirstButtonAction; a < ACT_COUNT; a++) {
            ImGui::TableNextRow();
            ImGui::TableSetColumnIndex(0);
            ImGui::AlignTextToFramePadding();
            ImGui::TextUnformatted(action_name(a));
            ImGui::TableSetColumnIndex(1);
            if (bind_button(s.pad[a], true, a, 0)) { s.pad[a] = Bind{}; ch = true; }
        }
        ImGui::EndTable();
    }
    ImGui::Spacing();
    if (ImGui::Button("Nintendo layout (swap A/B and X/Y)")) {
        std::swap(s.pad[ACT_A], s.pad[ACT_B]);
        std::swap(s.pad[ACT_X], s.pad[ACT_Y]);
        ch = true;
    }
    help("Puts GameCube A/B on the buttons in the same positions as on a Switch Pro / Nintendo layout.");
    ImGui::SameLine();
    if (ImGui::Button("Reset gamepad to defaults")) { s.reset_gamepad(); ch = true; }
    return ch;
}

} // namespace

bool menu_open() { return g_open; }
void menu_set_open(bool open) { g_open = open; if (!open) g_cap.active = false; }
void menu_select_tab(int tab) { g_select_tab = tab; }
bool menu_capturing() { return g_open && g_cap.active; }

bool menu_handle_event(const SDL_Event& e, Settings& s, bool& changed) {
    if (!menu_capturing()) return false;
    if (e.type == SDL_KEYDOWN && e.key.keysym.scancode == SDL_SCANCODE_ESCAPE) { g_cap.active = false; return true; }
    if (!g_cap.pad) {
        if (e.type == SDL_KEYDOWN && !e.key.repeat) {
            SDL_Scancode sc = e.key.keysym.scancode;
            if (sc == SDL_SCANCODE_F12) return true;  // reserved for the menu
            assign(s, Bind::key(sc));
            changed = true;
            return true;
        }
        if (e.type == SDL_MOUSEBUTTONDOWN) {
            if (ImGui::GetIO().WantCaptureMouse && e.button.button == SDL_BUTTON_LEFT && !ImGui::IsAnyItemHovered())
                return false;  // clicking empty menu space: not a binding
            assign(s, Bind::mouse(e.button.button));
            changed = true;
            return true;
        }
        if (e.type == SDL_KEYUP || e.type == SDL_TEXTINPUT) return true;
    } else {
        if (e.type == SDL_CONTROLLERBUTTONDOWN) {
            if (e.cbutton.button == SDL_CONTROLLER_BUTTON_BACK) { g_cap.active = false; return true; }  // reserved
            assign(s, Bind::button(SDL_GameControllerButton(e.cbutton.button)));
            changed = true;
            return true;
        }
        if (e.type == SDL_CONTROLLERAXISMOTION && e.caxis.value > 24000 &&
            (e.caxis.axis == SDL_CONTROLLER_AXIS_TRIGGERLEFT || e.caxis.axis == SDL_CONTROLLER_AXIS_TRIGGERRIGHT)) {
            assign(s, Bind::axis(SDL_GameControllerAxis(e.caxis.axis)));
            changed = true;
            return true;
        }
    }
    return false;
}

bool draw_menu(Settings& s, const MenuInfo& info) {
    if (!g_open) return false;
    bool ch = false;
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    ImVec2 size(std::min(760.f, vp->Size.x - 40), std::min(640.f, vp->Size.y - 40));
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + vp->Size.x * 0.5f, vp->Pos.y + vp->Size.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    ImGui::SetNextWindowSize(size, ImGuiCond_Always);
    ImGui::SetNextWindowBgAlpha(1.0f);
    bool open = true;
    ImGui::Begin("Settings", &open, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                                        ImGuiWindowFlags_NoSavedSettings);
    ImGui::TextColored(kAccent, "SILLY REENCOUNTER - Settings");
    ImGui::SameLine();
    ImGui::TextColored(kDim, "   F12 / Esc to close. Changes apply and save immediately.");
    ch |= ImGui::Checkbox("Pause the game while this menu is open", &s.pause_in_menu);
    if (ImGui::BeginTabBar("##tabs")) {
        if (ImGui::BeginTabItem("Graphics", nullptr, g_select_tab == 0 ? ImGuiTabItemFlags_SetSelected : 0)) { ImGui::BeginChild("##g"); ch |= tab_graphics(s, info); ImGui::EndChild(); ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Audio", nullptr, g_select_tab == 1 ? ImGuiTabItemFlags_SetSelected : 0)) { ImGui::BeginChild("##a"); ch |= tab_audio(s); ImGui::EndChild(); ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Keyboard & Mouse", nullptr, g_select_tab == 2 ? ImGuiTabItemFlags_SetSelected : 0)) { ImGui::BeginChild("##k"); ch |= tab_keyboard(s); ImGui::EndChild(); ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Gamepad", nullptr, g_select_tab == 3 ? ImGuiTabItemFlags_SetSelected : 0)) { ImGui::BeginChild("##p"); ch |= tab_gamepad(s, info); ImGui::EndChild(); ImGui::EndTabItem(); }
        if (ImGui::BeginTabItem("Hotkeys", nullptr, g_select_tab == 4 ? ImGuiTabItemFlags_SetSelected : 0)) { ImGui::BeginChild("##h"); tab_hotkeys(); ImGui::EndChild(); ImGui::EndTabItem(); }
        ImGui::EndTabBar();
        g_select_tab = -1;
    }
    ImGui::End();
    if (!open) menu_set_open(false);
    return ch;
}

} // namespace port
