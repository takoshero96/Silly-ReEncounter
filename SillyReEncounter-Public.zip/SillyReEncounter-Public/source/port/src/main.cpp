// ssne-port: the PC executable. Boots the recompiled game on a guest thread and shows a live
// status window (game log, GPU/disc/audio activity) while the GX renderer is being built.
#include <SDL.h>
#ifdef _WIN32
#include <windows.h>
#include <timeapi.h>
#endif
#include <SDL_opengl.h>
#include <imgui.h>
#include <imgui_impl_opengl3.h>
#include <imgui_impl_sdl2.h>

#include <algorithm>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <filesystem>
#include <mutex>
#include <stdexcept>
#include <string>
#include <chrono>
#include <thread>
#include <vector>

#include "ssne/audio.h"
#include "ssne/exi.h"
#include "ssne/gx.h"
#include "ssne/gx_gpu.h"
#include "ssne/hw.h"
#include "ssne/input.h"
#include "ssne/recomp_hooks.h"
#include "ssne/runtime.h"
#include "ssne/scheduler.h"
#include "ssne/thread_util.h"
#include "settings.h"
#include "settings_menu.h"

namespace {

std::mutex g_log_mutex;
std::deque<std::string> g_log;
FILE* g_log_file = nullptr;
std::string g_status = "Starting...";
std::atomic<bool> g_guest_running{false};
bool g_scroll_to_bottom = true;

void log_line(const std::string& s) {
    std::lock_guard<std::mutex> lk(g_log_mutex);
    g_log.push_back(s);
    if (g_log.size() > 4000) g_log.pop_front();
    if (g_log_file) { fprintf(g_log_file, "%s\n", s.c_str()); fflush(g_log_file); }
    g_scroll_to_bottom = true;
}

void set_status(const std::string& s) {
    {
        std::lock_guard<std::mutex> lk(g_log_mutex);
        g_status = s;
    }
    log_line("[port] " + s);
}

[[noreturn]] void throw_fatal(const char* msg) { throw std::runtime_error(msg); }

void guest_main(std::string data_dir) {
    g_guest_running = true;
    try {
        if (!g_ssne_has_game_code) {
            set_status("This build has no recompiled game code. Run ssne-recomp on your main.dol and rebuild "
                       "with -DSSNE_RECOMPILED_DIR (see docs/BUILDING.md).");
            g_guest_running = false;
            return;
        }
        static PPCContext ctx;
        std::string err;
        uint32_t entry = ssne::boot(ctx, data_dir, err);
        if (!entry) throw std::runtime_error(err);
        set_status("Running recompiled game code");
        ssne_call(ctx, entry);
        set_status("Game code returned from its entry point.");
    } catch (const std::exception& e) {
        set_status(std::string("Stopped: ") + e.what());
    }
    g_guest_running = false;
}

// ---------------------------------------------------------------- game view

GLuint g_tex = 0;
int g_tex_w = 0, g_tex_h = 0;
uint64_t g_frame_seq = 0;
std::vector<uint32_t> g_pixels;

void update_game_texture() {
    int w, h;
    if (!ssne::gx_get_frame(g_pixels, w, h, g_frame_seq)) return;
    if (!g_tex) {
        glGenTextures(1, &g_tex);
        glBindTexture(GL_TEXTURE_2D, g_tex);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    }
    glBindTexture(GL_TEXTURE_2D, g_tex);
    if (w != g_tex_w || h != g_tex_h) {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, g_pixels.data());
        g_tex_w = w;
        g_tex_h = h;
    } else {
        glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, g_pixels.data());
    }
}

bool g_gpu = false;       // GPU renderer active
// Main-loop heartbeat for the watchdog (hang diagnostics in ssne.log).
std::atomic<uint64_t> g_heartbeat{0};
std::atomic<const char*> g_loop_phase{"start"};

void watchdog() {
    uint64_t last = 0;
    int stuck = 0;
    for (;;) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        uint64_t hb = g_heartbeat.load();
        if (hb != last) {
            if (stuck >= 5) log_line("[watchdog] main loop resumed after " + std::to_string(stuck) + " s");
            last = hb; stuck = 0; continue;
        }
        stuck++;
        if (stuck == 5 || (stuck > 5 && stuck % 30 == 0)) {
            std::string msg = "[watchdog] main loop stuck for " + std::to_string(stuck) + " s in: " + g_loop_phase.load();
            if (g_gpu) msg += " | renderer: " + ssne::gpu_renderer_phase();
            log_line(msg);
        }
    }
}
// Settings (settings.ini next to the executable, F12 menu).
port::Settings g_set;
std::string g_settings_path;
// Widescreen modes (F8 cycles): factor applied to the game's horizontal field of view in gameplay.
struct AspectMode { const char* name; float factor; };
const AspectMode kAspects[] = {{"4:3", 1.0f}, {"16:9", 4.0f / 3.0f}, {"21:9", 7.0f / 4.0f}};
// Frame rate limit (F10 cycles these; the menu also offers 165 and 240): 60 = the game's own pacing.
const int kFpsModes[] = {60, 120, 144, 0};
std::string fps_mode_name(int v) { return v == 0 ? std::string("unlimited") : std::to_string(v); }
bool have_game_image() { return g_gpu ? ssne::gpu_renderer_output().texture != 0 : g_tex != 0; }

void draw_game_view() {
    GLuint tex = g_tex;
    if (g_gpu) tex = ssne::gpu_renderer_output().texture;
    if (!tex) return;
    const ImGuiViewport* vp = ImGui::GetMainViewport();
    // The GameCube image is 4:3 regardless of the EFB height (640x448/480 -> 4:3 on a TV); widescreen gameplay
    // frames are rendered wider and shown at 4:3 x factor (menus and cutscenes stay 4:3, pillarboxed).
    float factor = g_gpu ? ssne::gpu_renderer_output().wide : ssne::widescreen_frame_factor();
    float W = vp->Size.x, H = vp->Size.y, aspect = 4.f / 3.f * std::max(1.f, factor);
    float w = W, h = W / aspect;
    if (h > H) { h = H; w = H * aspect; }
    ImVec2 p0(vp->Pos.x + (W - w) * 0.5f, vp->Pos.y + (H - h) * 0.5f);
    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    dl->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
    dl->AddCallback([](const ImDrawList*, const ImDrawCmd*) { glDisable(GL_BLEND); }, nullptr);  // the game image is opaque
    dl->AddImage((ImTextureID)(intptr_t)tex, p0, ImVec2(p0.x + w, p0.y + h));
    dl->AddCallback(ImDrawCallback_ResetRenderState, nullptr);
}

// ---------------------------------------------------------------- input
// Keyboard/mouse and gamepad bindings come from g_set (defaults in settings.cpp; rebind in the F12 menu).
SDL_GameController* g_pad = nullptr;
float g_mouse_dx = 0, g_mouse_dy = 0;
bool g_mouse_captured = false;

uint8_t axis_to_u8(float v) { return uint8_t(std::clamp(128.f + v * 127.f, 0.f, 255.f)); }

void release_mouse() { g_mouse_captured = false; SDL_SetRelativeMouseMode(SDL_FALSE); }

// Radial deadzone with the remaining range rescaled to 0..1.
void deadzone(float& x, float& y, float dz) {
    float m = std::sqrt(x * x + y * y);
    if (m <= dz || m <= 0) { x = y = 0; return; }
    float k = std::min(1.f, (m - dz) / std::max(1e-3f, 1.f - dz)) / m;
    x *= k; y *= k;
}

void update_input(float dt) {
    ssne::PadState p;
    if (port::menu_open()) {  // the game gets a neutral controller while the menu is open
        g_mouse_dx = g_mouse_dy = 0;
        ssne::set_pad(0, p);
        return;
    }
    float lx = 0, ly = 0, cx = 0, cy = 0, lt = 0, rt = 0;
    float act[port::ACT_COUNT] = {};  // 0..1 per control
    const Uint8* k = SDL_GetKeyboardState(nullptr);
    Uint32 mb = g_mouse_captured ? SDL_GetMouseState(nullptr, nullptr) : 0;
    bool kb_ok = !ImGui::GetIO().WantCaptureKeyboard;
    for (int a = 0; a < port::ACT_COUNT; a++)
        for (const port::Bind& b : g_set.kb[a]) {
            if (b.type == port::Bind::KEY && kb_ok && b.code > 0 && b.code < SDL_NUM_SCANCODES && k[b.code]) act[a] = 1;
            if (b.type == port::Bind::MOUSE && (mb & SDL_BUTTON(b.code))) act[a] = 1;
        }
    if (g_pad) {
        for (int a = port::kFirstButtonAction; a < port::ACT_COUNT; a++) {
            const port::Bind& b = g_set.pad[a];
            float v = 0;
            if (b.type == port::Bind::PAD_BUTTON) v = SDL_GameControllerGetButton(g_pad, SDL_GameControllerButton(b.code)) ? 1.f : 0.f;
            else if (b.type == port::Bind::PAD_AXIS) v = std::max(0.f, SDL_GameControllerGetAxis(g_pad, SDL_GameControllerAxis(b.code)) / 32767.f);
            act[a] = std::max(act[a], v);
        }
        auto ax = [](SDL_GameControllerAxis a) { return SDL_GameControllerGetAxis(g_pad, a) / 32767.f; };
        float mx = ax(SDL_CONTROLLER_AXIS_LEFTX), my = -ax(SDL_CONTROLLER_AXIS_LEFTY);
        float rx = ax(SDL_CONTROLLER_AXIS_RIGHTX), ry = -ax(SDL_CONTROLLER_AXIS_RIGHTY);
        if (g_set.swap_sticks) { std::swap(mx, rx); std::swap(my, ry); }
        deadzone(mx, my, g_set.pad_deadzone);
        deadzone(rx, ry, g_set.pad_deadzone);
        lx += mx; ly += my;
        cx += rx * g_set.look_sens;
        cy += (g_set.pad_invert_y ? -ry : ry) * g_set.look_sens;
    }
    ly += act[port::ACT_MOVE_UP] - act[port::ACT_MOVE_DOWN];
    lx += act[port::ACT_MOVE_RIGHT] - act[port::ACT_MOVE_LEFT];
    cy += act[port::ACT_LOOK_UP] - act[port::ACT_LOOK_DOWN];
    cx += act[port::ACT_LOOK_RIGHT] - act[port::ACT_LOOK_LEFT];
    struct { int a; uint16_t m; } map[] = {
        {port::ACT_A, ssne::PAD_A}, {port::ACT_B, ssne::PAD_B}, {port::ACT_X, ssne::PAD_X}, {port::ACT_Y, ssne::PAD_Y},
        {port::ACT_Z, ssne::PAD_Z}, {port::ACT_START, ssne::PAD_START},
        {port::ACT_DPAD_UP, ssne::PAD_UP}, {port::ACT_DPAD_DOWN, ssne::PAD_DOWN},
        {port::ACT_DPAD_LEFT, ssne::PAD_LEFT}, {port::ACT_DPAD_RIGHT, ssne::PAD_RIGHT}};
    for (auto& m : map) if (act[m.a] >= 0.5f) p.buttons |= m.m;
    lt = act[port::ACT_L];
    rt = act[port::ACT_R];
    if (g_mouse_captured && g_set.mouse_look && g_set.mouse_aim && ssne::mouse_aim_active()) {
        // Direct aim: mouse counts -> radians, applied to the player's view by the runtime (no C-stick).
        const double k = 0.0012 * g_set.mouse_sens;
        ssne::mouse_aim_add(g_mouse_dx * k, (g_set.mouse_invert_y ? g_mouse_dy : -g_mouse_dy) * k);
    } else if (g_mouse_captured && g_set.mouse_look) {
        // Mouse motion drives the C-stick (menus, or direct aim off); scaled per frame so speed doesn't depend on frame rate.
        float sens = 0.02f * g_set.mouse_sens;
        cx += std::clamp(g_mouse_dx * sens / std::max(dt * 60.f, 0.25f), -1.f, 1.f);
        float dy = std::clamp(g_mouse_dy * sens / std::max(dt * 60.f, 0.25f), -1.f, 1.f);
        cy += g_set.mouse_invert_y ? dy : -dy;
    }
    g_mouse_dx = g_mouse_dy = 0;
    p.stick_x = axis_to_u8(std::clamp(lx, -1.f, 1.f));
    p.stick_y = axis_to_u8(std::clamp(ly, -1.f, 1.f));
    p.cstick_x = axis_to_u8(std::clamp(cx, -1.f, 1.f));
    p.cstick_y = axis_to_u8(std::clamp(cy, -1.f, 1.f));
    p.trigger_l = uint8_t(std::clamp(lt, 0.f, 1.f) * 255);
    p.trigger_r = uint8_t(std::clamp(rt, 0.f, 1.f) * 255);
    float click = std::min(g_set.trigger_threshold, 0.999f);
    if (lt >= click) p.buttons |= ssne::PAD_L;   // full press = digital click, as on the real controller
    if (rt >= click) p.buttons |= ssne::PAD_R;
    ssne::set_pad(0, p);
}

// ---------------------------------------------------------------- audio
// The emulated AI DMA plays the game's mix in real time into a FIFO; the SDL callback drains it. The two clocks
// drift slightly, so the callback keeps the FIFO between ~40 and ~200 ms: it skips ahead when too much is queued
// and re-buffers a little after an underrun.
std::atomic<int> g_volume{100};
std::atomic<bool> g_muted{false};
SDL_AudioDeviceID g_audio_dev = 0;

void audio_callback(void*, Uint8* stream, int len) {
    static bool buffering = true;
    auto* out = reinterpret_cast<int16_t*>(stream);
    uint32_t frames = uint32_t(len / 4);
    uint32_t rate = ssne::audio_rate();
    uint32_t queued = ssne::audio_buffered();
    if (queued > rate * 200 / 1000) {  // too much latency: drop the oldest audio
        static std::vector<int16_t> sink;
        uint32_t drop = queued - rate * 80 / 1000;
        sink.resize(size_t(drop) * 2);
        ssne::audio_pull(sink.data(), drop);
        queued -= drop;
    }
    if (ssne::paused()) {  // game frozen by the settings menu: discard whatever the AI keeps producing
        static std::vector<int16_t> sink;
        sink.resize(size_t(queued) * 2);
        ssne::audio_pull(sink.data(), queued);
        memset(stream, 0, size_t(len));
        buffering = true;
        return;
    }
    if (buffering && queued < frames + rate * 40 / 1000) { memset(stream, 0, size_t(len)); return; }
    buffering = false;
    uint32_t got = ssne::audio_pull(out, frames);
    if (got < frames) buffering = true;
    int vol = g_muted ? 0 : g_volume.load();
    if (vol != 100)
        for (uint32_t i = 0; i < frames * 2; i++) out[i] = int16_t(std::clamp(int32_t(out[i]) * vol / 100, -32768, 32767));
}

void open_audio() {
    SDL_AudioSpec want{}, have{};
    want.freq = 32000;  // AX mixes at 32 kHz
    want.format = AUDIO_S16SYS;
    want.channels = 2;
    want.samples = 512;
    want.callback = audio_callback;
    g_audio_dev = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);  // SDL converts to the device's format
    if (!g_audio_dev) { log_line(std::string("[audio] no audio device: ") + SDL_GetError()); return; }
    ssne::audio_set_sink_active(true);
    SDL_PauseAudioDevice(g_audio_dev, 0);
    log_line("[audio] output: " + std::string(SDL_GetCurrentAudioDriver() ? SDL_GetCurrentAudioDriver() : "?") +
             ", 32000 Hz stereo");
}

// ---------------------------------------------------------------- overlay (F1)
bool g_show_overlay = false;

void draw_overlay(const std::string& data_dir, float dt) {
    static uint64_t last_copies = 0;
    static float fps_timer = 0, fps = 0;
    auto rs = ssne::gx_render_stats();
    auto hw = ssne::hw_stats();
    auto st = ssne::scheduler_stats();
    fps_timer += dt;
    if (fps_timer >= 1.0f) { fps = float(rs.display_copies - last_copies) / fps_timer; last_copies = rs.display_copies; fps_timer = 0; }

    if (g_set.show_top_bar) {
        ImGui::SetNextWindowPos(ImVec2(8, 8), ImGuiCond_Always);
        ImGui::SetNextWindowBgAlpha(0.45f);
        ImGui::Begin("##fps", nullptr, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs |
                                       ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing);
        ImGui::Text("%.0f fps (limit %s)   F12: settings & hotkeys   F1: log/stats   Shift+F1: hide this bar%s", fps,
                    fps_mode_name(ssne::frame_limit()).c_str(), ssne::paused() ? "   [paused]" : "");
        ImGui::End();
    }
    if (!have_game_image() || g_show_overlay) {
        const ImGuiViewport* vp = ImGui::GetMainViewport();
        ImGui::SetNextWindowPos(ImVec2(vp->Pos.x + 20, vp->Pos.y + 50), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(760, 420), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowBgAlpha(0.85f);
        ImGui::Begin("Silly ReEncounter - development build");
        {
            std::lock_guard<std::mutex> lk(g_log_mutex);
            ImGui::TextWrapped("%s", g_status.c_str());
        }
        ImGui::Text("Frames %llu  |  triangles %llu  |  textures %llu  |  disc reads %llu (%llu KB)  |  interrupts %llu, threads %d",
                    (unsigned long long)rs.display_copies, (unsigned long long)rs.triangles, (unsigned long long)rs.textures_decoded,
                    (unsigned long long)hw.disc_reads, (unsigned long long)(hw.disc_bytes / 1024), (unsigned long long)st.interrupts, st.threads);
        ImGui::Text("Data: %s   Recompiled functions: %zu   Controller: %s", data_dir.c_str(), g_ssne_func_count,
                    g_pad ? SDL_GameControllerName(g_pad) : "keyboard/mouse");
        {
            auto au = ssne::audio_stats();
            ImGui::Text("Audio: %s  volume %d%% (F3 mute, F4/F5 -/+)  |  %u voices  |  %u ms queued  |  %llu underruns",
                        g_audio_dev ? (g_muted ? "muted" : "on") : "no device", g_volume.load(), au.active_voices,
                        ssne::audio_buffered() * 1000 / std::max(1u, ssne::audio_rate()), (unsigned long long)au.underruns);
        }
        if (g_gpu) {
            auto gs = ssne::gpu_renderer_stats();
            auto o = ssne::gpu_renderer_output();
            ImGui::Text("Renderer: GPU %dx (%dx%d, F6/F7 to change) | %s | %.1f ms/frame, %llu draws, %llu shaders",
                        ssne::gpu_renderer_scale(), o.w, o.h, ssne::gpu_renderer_info().c_str(), gs.frame_ms,
                        (unsigned long long)gs.draws, (unsigned long long)gs.programs);
        } else {
            ImGui::Text("Renderer: software (CPU)");
        }
        {
            std::string mc = ssne::exi_memcard_path();
            ImGui::Text("Memory card A: %s", mc.empty() ? "none" : mc.c_str());
        }
        ImGui::Separator();
        ImGui::BeginChild("##log", ImVec2(0, 0), ImGuiChildFlags_Borders, ImGuiWindowFlags_HorizontalScrollbar);
        {
            std::lock_guard<std::mutex> lk(g_log_mutex);
            ImGuiListClipper clip;
            clip.Begin(int(g_log.size()));
            while (clip.Step())
                for (int i = clip.DisplayStart; i < clip.DisplayEnd; i++) ImGui::TextUnformatted(g_log[size_t(i)].c_str());
            if (g_scroll_to_bottom) { ImGui::SetScrollHereY(1.0f); g_scroll_to_bottom = false; }
        }
        ImGui::EndChild();
        ImGui::End();
    }
}

// Applies g_set to the running game/renderer/window. `win` may be null before the window exists.
void apply_settings(SDL_Window* win) {
    ssne::set_widescreen(kAspects[std::clamp(g_set.aspect, 0, 2)].factor);
    ssne::set_frame_limit(g_set.fps_limit);
    ssne::set_fov(float(g_set.fov));
    g_volume = g_set.volume;
    g_muted = g_set.muted;
    ssne::audio_set_hq(g_set.audio_hq);
    if (win) {
        SDL_GL_SetSwapInterval(g_set.vsync ? 1 : 0);
        bool fs = (SDL_GetWindowFlags(win) & SDL_WINDOW_FULLSCREEN_DESKTOP) == SDL_WINDOW_FULLSCREEN_DESKTOP;
        if (fs != g_set.fullscreen) SDL_SetWindowFullscreen(win, g_set.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0);
        if (g_gpu && ssne::gpu_renderer_scale() != g_set.scale) ssne::gpu_renderer_set_scale(g_set.scale);
    }
}

void save_now() {
    if (!port::save_settings(g_set, g_settings_path)) log_line("[port] could not save " + g_settings_path);
}

} // namespace

int main(int argc, char** argv) {
    std::string data_dir = "game_data";
    bool headless = false;
    std::string memcard;  // default: saves/MemoryCardA.USA.raw next to the executable
    std::string base_dir;
    {
        char* base = SDL_GetBasePath();
        base_dir = base ? base : "";
        SDL_free(base);
    }
    g_settings_path = base_dir + "settings.ini";
    bool have_file = port::load_settings(g_set, g_settings_path);
    // Command-line options override settings.ini for this run (and are saved if the menu changes anything).
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i];
        if (a == "--data" && i + 1 < argc) data_dir = argv[++i];
        else if (a == "--headless") headless = true;
        else if (a == "--fullscreen") g_set.fullscreen = true;
        else if (a == "--volume" && i + 1 < argc) g_set.volume = std::clamp(atoi(argv[++i]), 0, 200);
        else if (a == "--mute") g_set.muted = true;
        else if (a == "--memcard" && i + 1 < argc) memcard = argv[++i];
        else if (a == "--no-memcard") memcard = "-";
        else if (a == "--renderer" && i + 1 < argc) g_set.renderer = argv[++i];
        else if (a == "--aspect" && i + 1 < argc) {
            std::string v = argv[++i];
            for (int k = 0; k < 3; k++) if (v == kAspects[k].name) g_set.aspect = k;
        }
        else if (a == "--scale" && i + 1 < argc) g_set.scale = std::clamp(atoi(argv[++i]), 1, 8);
        else if (a == "--fov" && i + 1 < argc) g_set.fov = std::clamp(atoi(argv[++i]), 45, 110);
        else if (a == "--fps" && i + 1 < argc) {
            std::string v = argv[++i];
            g_set.fps_limit = v == "unlimited" ? 0 : std::max(0, atoi(v.c_str()));
        }
    }
    ssne::set_fatal_handler(throw_fatal);
    if (memcard.empty()) memcard = base_dir + "saves/MemoryCardA.USA.raw";
    ssne::exi_configure_memcard(memcard == "-" ? std::string() : memcard);
    apply_settings(nullptr);
#ifdef _WIN32
    timeBeginPeriod(1);  // 1 ms sleeps for the audio/VI/alarm timers (default is ~15.6 ms)
#endif
    g_log_file = fopen("ssne.log", "w");
    ssne::set_log_sink([](const char* line) { log_line(line); });
    log_line(have_file ? "[port] settings: " + g_settings_path : "[port] settings: defaults (" + g_settings_path + " will be created)");
    if (!have_file) save_now();

    if (headless) {
        guest_main(data_dir);
        return 0;
    }

    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER) != 0) {
        fprintf(stderr, "SDL_Init failed: %s\n", SDL_GetError());
        return 1;
    }
    if (SDL_InitSubSystem(SDL_INIT_AUDIO) != 0)  // no audio device: play silently
        log_line(std::string("[audio] audio unavailable: ") + SDL_GetError());
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_Window* win = SDL_CreateWindow("Silly ReEncounter", SDL_WINDOWPOS_CENTERED,
                                       SDL_WINDOWPOS_CENTERED, 1280, 720,
                                       SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | SDL_WINDOW_ALLOW_HIGHDPI);
    SDL_GLContext gl = SDL_GL_CreateContext(win);
    bool core = gl != nullptr;
    if (!gl) {  // no GL 3.3 core: fall back to a basic context and the software renderer
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, 0);
        SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 0);
        gl = SDL_GL_CreateContext(win);
        log_line("[gpu] OpenGL 3.3 core not available; using the software renderer");
    }
    if (!gl) { fprintf(stderr, "SDL_GL_CreateContext failed: %s\n", SDL_GetError()); return 1; }
    if (core && g_set.renderer != "software") {
        std::string err;
        if (ssne::gpu_renderer_init(SDL_GL_GetProcAddress, g_set.scale, err)) {
            g_gpu = true;
            ssne::gx_use_gpu(true);
            log_line("[gpu] " + ssne::gpu_renderer_info() + ", internal resolution " + std::to_string(g_set.scale) + "x");
        } else {
            log_line("[gpu] GPU renderer unavailable (" + err + "); using the software renderer");
        }
    }
    apply_settings(win);
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::GetIO().IniFilename = nullptr;
    ImGui::GetIO().ConfigFlags |= ImGuiConfigFlags_NavEnableGamepad;  // the settings menu works with a controller
    ImGui::StyleColorsDark();
    ImGui_ImplSDL2_InitForOpenGL(win, gl);
    ImGui_ImplOpenGL3_Init(core ? "#version 330 core" : "#version 130");

    open_audio();
    std::thread(watchdog).detach();
    ssne::spawn_guest_thread([data_dir] { guest_main(data_dir); });  // never returns (game loop)

    if (const char* t = getenv("SSNE_OPEN_MENU")) {  // development: open the menu on a tab at startup (screenshots)
        port::menu_set_open(true);
        port::menu_select_tab(atoi(t));
    }
    auto toggle_menu = [&] {
        port::menu_set_open(!port::menu_open());
        if (port::menu_open()) release_mouse();
        else save_now();
    };
    bool quit = false;
    uint32_t last = SDL_GetTicks();
    while (!quit) {
        SDL_Event e;
        bool changed = false;  // settings changed by hotkeys/menu this frame
        while (SDL_PollEvent(&e)) {
            if (port::menu_handle_event(e, g_set, changed)) continue;  // rebinding in progress
            ImGui_ImplSDL2_ProcessEvent(&e);
            switch (e.type) {
            case SDL_QUIT: quit = true; break;
            case SDL_KEYDOWN: {
                SDL_Scancode sc = e.key.keysym.scancode;
                if (sc == SDL_SCANCODE_F12 && !e.key.repeat) { toggle_menu(); break; }
                if (sc == SDL_SCANCODE_ESCAPE && port::menu_open()) { toggle_menu(); break; }
                if (sc == SDL_SCANCODE_F1 && !e.key.repeat) {
                    if (e.key.keysym.mod & KMOD_SHIFT) { g_set.show_top_bar = !g_set.show_top_bar; changed = true; }
                    else g_show_overlay = !g_show_overlay;
                }
                if (sc == SDL_SCANCODE_F3) { g_set.muted = !g_set.muted; changed = true; }
                if (sc == SDL_SCANCODE_F10) {
                    int k = -1;
                    for (int j = 0; j < 4; j++) if (kFpsModes[j] == g_set.fps_limit) k = j;
                    g_set.fps_limit = kFpsModes[(k + 1) % 4];
                    changed = true;
                    log_line("[port] frame rate limit: " + fps_mode_name(g_set.fps_limit));
                }
                if (sc == SDL_SCANCODE_F8) {
                    g_set.aspect = (g_set.aspect + 1) % 3;
                    changed = true;
                    log_line(std::string("[port] aspect ratio: ") + kAspects[g_set.aspect].name);
                }
                if (g_gpu && sc == SDL_SCANCODE_F9) {
                    std::string dir = base_dir + "debug";
                    std::error_code ec;
                    std::filesystem::create_directories(std::filesystem::u8path(dir), ec);
                    ssne::gpu_renderer_request_dump(dir);
                    log_line("[gpu] F9: capturing the next frame to " + dir);
                }
                if (g_gpu && sc == SDL_SCANCODE_F6) { g_set.scale = std::max(1, g_set.scale - 1); changed = true; }
                if (g_gpu && sc == SDL_SCANCODE_F7) { g_set.scale = std::min(8, g_set.scale + 1); changed = true; }
                if (sc == SDL_SCANCODE_F4) { g_set.volume = std::max(0, g_set.volume - 10); changed = true; }
                if (sc == SDL_SCANCODE_F5) { g_set.volume = std::min(200, g_set.volume + 10); changed = true; }
                if (sc == SDL_SCANCODE_F2) release_mouse();
                if (sc == SDL_SCANCODE_F11 || (sc == SDL_SCANCODE_RETURN && (e.key.keysym.mod & KMOD_ALT))) {
                    g_set.fullscreen = !g_set.fullscreen;
                    changed = true;
                }
                break;
            }
            case SDL_MOUSEBUTTONDOWN:
                if (!g_mouse_captured && !port::menu_open() && g_set.mouse_look && !ImGui::GetIO().WantCaptureMouse &&
                    have_game_image()) {
                    g_mouse_captured = true;
                    SDL_SetRelativeMouseMode(SDL_TRUE);
                }
                break;
            case SDL_MOUSEMOTION:
                if (g_mouse_captured) { g_mouse_dx += float(e.motion.xrel); g_mouse_dy += float(e.motion.yrel); }
                break;
            case SDL_CONTROLLERBUTTONDOWN:
                if (e.cbutton.button == SDL_CONTROLLER_BUTTON_BACK) toggle_menu();
                break;
            case SDL_CONTROLLERDEVICEADDED:
                if (!g_pad) g_pad = SDL_GameControllerOpen(e.cdevice.which);
                break;
            case SDL_CONTROLLERDEVICEREMOVED:
                if (g_pad && SDL_GameControllerGetAttached(g_pad) == SDL_FALSE) { SDL_GameControllerClose(g_pad); g_pad = nullptr; }
                break;
            case SDL_WINDOWEVENT:
                if (e.window.event == SDL_WINDOWEVENT_FOCUS_LOST) release_mouse();
                break;
            default: break;
            }
        }
        uint32_t now = SDL_GetTicks();
        float dt = float(now - last) / 1000.0f;
        last = now;
        update_input(dt);
        ssne::set_paused(port::menu_open() && g_set.pause_in_menu);
        g_heartbeat++;
        if (g_gpu) {
            g_loop_phase = "running GPU frames";
            ssne::gpu_renderer_run(2);
            static uint32_t next_stats = SDL_GetTicks() + 10000;
            if (SDL_GetTicks() >= next_stats) {  // periodic renderer stats in ssne.log (diagnostics)
                next_stats += 10000;
                auto gs = ssne::gpu_renderer_stats();
                auto o = ssne::gpu_renderer_output();
                char buf[256];
                snprintf(buf, sizeof(buf), "[gpu] frames %llu (dropped %llu), draws %llu, copies %llu, uploads %llu, shaders %llu, render targets %llu, last %.1f ms, worst %.1f ms, output %dx%d",
                         (unsigned long long)gs.frames, (unsigned long long)ssne::gpu_dropped_frames(), (unsigned long long)gs.draws,
                         (unsigned long long)gs.tex_copies, (unsigned long long)gs.uploads, (unsigned long long)gs.programs,
                         (unsigned long long)gs.render_targets, gs.frame_ms, ssne::gpu_renderer_take_max_frame_ms(), o.w, o.h);
                log_line(buf);
            }
        }
        else update_game_texture();
        g_loop_phase = "UI";
        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplSDL2_NewFrame();
        ImGui::NewFrame();
        draw_game_view();
        draw_overlay(data_dir, dt);
        {
            port::MenuInfo mi;
            mi.gpu_active = g_gpu;
            if (g_gpu) {
                mi.renderer_info = ssne::gpu_renderer_info();
                auto o = ssne::gpu_renderer_output();
                mi.out_w = o.w; mi.out_h = o.h;
            }
            if (g_pad) mi.pad_name = SDL_GameControllerName(g_pad) ? SDL_GameControllerName(g_pad) : "controller";
            mi.settings_path = g_settings_path;
            bool was_open = port::menu_open();
            changed |= port::draw_menu(g_set, mi);
            if (was_open && !port::menu_open()) save_now();  // closed with the window's X button
        }
        if (changed) { apply_settings(win); save_now(); }
        ImGui::Render();
        int w, h;
        SDL_GL_GetDrawableSize(win, &w, &h);
        glViewport(0, 0, w, h);
        glClearColor(0, 0, 0, 1);
        glClear(GL_COLOR_BUFFER_BIT);
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
        if (const char* shot = getenv("SSNE_SCREENSHOT")) {  // development: save the window after ~3 s and exit
            static uint32_t at = SDL_GetTicks() + 3000;
            if (SDL_GetTicks() >= at) {
                std::vector<uint8_t> px(size_t(w) * h * 4);
                glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
                SDL_Surface* sf = SDL_CreateRGBSurfaceWithFormat(0, w, h, 32, SDL_PIXELFORMAT_ABGR8888);
                for (int y = 0; y < h; y++) memcpy((uint8_t*)sf->pixels + size_t(y) * sf->pitch, &px[size_t(h - 1 - y) * w * 4], size_t(w) * 4);
                SDL_SaveBMP(sf, shot);
                SDL_FreeSurface(sf);
                quit = true;
            }
        }
        g_loop_phase = "present (SwapWindow)";
        SDL_GL_SwapWindow(win);
        g_loop_phase = "events";
    }
    ssne::set_paused(false);
    save_now();
    ssne::scheduler_shutdown();
    if (g_log_file) fclose(g_log_file);
    std::_Exit(0);  // guest threads may still be inside game code
}
